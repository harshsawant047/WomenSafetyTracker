from flask import render_template, redirect, url_for, flash, request, jsonify, session
from flask_login import login_user, logout_user, login_required, current_user
from app import app, db
from models import User, EmergencyContact, CommunityReport, SafetyResource, IndiaAdminBoundary, IndiaEmergencyHelpline
from werkzeug.security import generate_password_hash
import json
import os
import pandas as pd
from datetime import datetime, timedelta
from pytz import timezone
from services import crime_data, location, safety_model, emergency, routing, database, india_crime_data
from services.india_map import get_map_api_config, get_india_emergency_helplines, geocode_address, reverse_geocode, get_safe_route, find_nearby_safety_resources, get_india_states

@app.route('/')
def index():
    # Get India-specific heatmap data for the homepage
    india_crime_points = india_crime_data.get_india_heatmap_data()
    return render_template('index.html', crime_points=json.dumps(india_crime_points))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Validate input
        if not all([username, email, password, confirm_password]):
            flash('All fields are required', 'danger')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('register.html')
        
        # Check if user exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'danger')
            return render_template('register.html')
        
        # Create new user
        user = User(username=username, email=email)
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful. Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember_me = 'remember_me' in request.form
        
        # Validate input
        if not all([username, password]):
            flash('Username and password are required', 'danger')
            return render_template('login.html')
        
        # Authenticate user
        user = User.query.filter_by(username=username).first()
        if user is None or not user.check_password(password):
            flash('Invalid username or password', 'danger')
            return render_template('login.html')
        
        login_user(user, remember=remember_me)
        flash('Login successful', 'success')
        
        next_page = request.args.get('next')
        if not next_page or next_page.startswith('/'):
            next_page = url_for('index')
        
        return redirect(next_page)
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        # Update profile information
        current_user.first_name = request.form.get('first_name')
        current_user.last_name = request.form.get('last_name')
        current_user.phone_number = request.form.get('phone_number')
        
        db.session.commit()
        flash('Profile updated successfully', 'success')
        return redirect(url_for('profile'))
    
    emergency_contacts = EmergencyContact.query.filter_by(user_id=current_user.id).all()
    return render_template('profile.html', emergency_contacts=emergency_contacts)
@app.route('/emergency-contacts', methods=['POST'])
@login_required
def add_emergency_contact():
    name = request.form.get('name')
    phone_number = request.form.get('phone_number')
    email = request.form.get('email')
    relationship = request.form.get('relationship')
    
    if not all([name, phone_number]):
        flash('Name and phone number are required', 'danger')
        return redirect(url_for('profile'))
    
    contact = EmergencyContact(
        user_id=current_user.id,
        name=name,
        phone_number=phone_number,
        email=email,
        relationship=relationship
    )
    
    db.session.add(contact)
    db.session.commit()
    
    flash('Emergency contact added successfully', 'success')
    return redirect(url_for('profile'))

@app.route('/emergency-contacts/<int:contact_id>/delete', methods=['POST'])
@login_required
def delete_emergency_contact(contact_id):
    contact = EmergencyContact.query.get_or_404(contact_id)
    
    # Verify that the contact belongs to the current user
    if contact.user_id != current_user.id:
        flash('You do not have permission to delete this contact', 'danger')
        return redirect(url_for('profile'))
    
    db.session.delete(contact)
    db.session.commit()
    
    flash('Emergency contact deleted successfully', 'success')
    return redirect(url_for('profile'))

@app.route('/heatmap')
def heatmap():
    # Get India-specific state-wise crime data for heatmap from CSV directly
    india_crime_points = india_crime_data.get_india_heatmap_data()
    
    # Get crime trend data for visualization
    crime_trend = india_crime_data.get_india_crime_trend()
    
    # Get crime type distribution data
    crime_distribution = india_crime_data.get_india_crime_distribution()
    
    # Get risk analysis data for states
    risk_analysis = india_crime_data.get_india_risk_analysis()
    
    return render_template('heatmap.html', 
                          crime_points=json.dumps(india_crime_points),
                          crime_trend=json.dumps(crime_trend),
                          crime_distribution=json.dumps(crime_distribution),
                          risk_analysis=risk_analysis)

@app.route('/risk-analysis', methods=['GET'])
def risk_analysis():
    # Get India state-wise risk analysis data
    risk_data = india_crime_data.get_india_risk_analysis()
    crime_distribution = india_crime_data.get_india_crime_distribution()
    
    return render_template('risk_analysis.html', 
                          risk_data=risk_data,
                          crime_distribution=json.dumps(crime_distribution))

# Safe routes functionality removed as requested by user

@app.route('/emergency')
@login_required
def emergency_page():
    emergency_contacts = EmergencyContact.query.filter_by(user_id=current_user.id).all()
    emergency_helplines = get_india_emergency_helplines()
    return render_template('emergency.html', 
                          emergency_contacts=emergency_contacts,
                          emergency_helplines=emergency_helplines)

@app.route('/api/send-sos', methods=['POST'])
@login_required
def send_sos():
    data = request.get_json()
    lat = data.get('lat')
    lng = data.get('lng')
    
    # Send SOS to emergency contacts
    result = emergency.send_sos_alerts(current_user.id, lat, lng)
    
    return jsonify(result)

@app.route('/community', methods=['GET', 'POST'])
def community():
    if request.method == 'POST' and current_user.is_authenticated:
        # Submit a new community report
        title = request.form.get('title')
        description = request.form.get('description')
        incident_type = request.form.get('incident_type')
        latitude = request.form.get('latitude')
        longitude = request.form.get('longitude')
        location_name = request.form.get('location_name')
        is_anonymous = 'is_anonymous' in request.form
        
        if not all([title, description, incident_type, latitude, longitude]):
            flash('All required fields must be filled', 'danger')
            return redirect(url_for('community'))
        
        report = CommunityReport(
            user_id=current_user.id,
            title=title,
            description=description,
            incident_type=incident_type,
            latitude=float(latitude),
            longitude=float(longitude),
            location_name=location_name,
            is_anonymous=is_anonymous
        )
        
        db.session.add(report)
        db.session.commit()
        
        flash('Report submitted successfully', 'success')
        return redirect(url_for('community'))
    
    # Get all community reports
    reports = CommunityReport.query.order_by(CommunityReport.created_at.desc()).all()
    
    return render_template('community.html', reports=reports)

@app.route('/api/safety-resources')
def get_safety_resources():
    lat = request.args.get('lat', type=float)
    lng = request.args.get('lng', type=float)
    resource_type = request.args.get('type')
    
    if not all([lat, lng]):
        return jsonify({'error': 'Latitude and longitude are required'}), 400
    
    # Filter resources by type if provided
    query = SafetyResource.query
    if resource_type:
        query = query.filter_by(resource_type=resource_type)
    
    # Get nearby resources (simple implementation)
    resources = query.all()
    
    # Sort by distance (would be better to do this in the query with a spatial database)
    nearby_resources = location.sort_by_distance(resources, lat, lng)
    
    return jsonify({
        'resources': [{
            'id': r.id,
            'name': r.name,
            'type': r.resource_type,
            'description': r.description,
            'lat': r.latitude,
            'lng': r.longitude,
            'address': r.address,
            'phone': r.phone_number
        } for r in nearby_resources[:10]]  # Return top 10 closest
    })

# API endpoint for crime data
@app.route('/api/crime-data')
def api_crime_data():
    lat = request.args.get('lat', type=float)
    lng = request.args.get('lng', type=float)
    radius = request.args.get('radius', default=1, type=float)  # km
    
    if not all([lat, lng]):
        return jsonify({'error': 'Latitude and longitude are required'}), 400
    
    crime_data_points = crime_data.get_nearby_crime_data(lat, lng, radius)
    
    return jsonify({
        'crimes': crime_data_points
    })

# India-specific routes and API endpoints
@app.route('/india-map')
def india_map():
    """India-specific map view with MapmyIndia integration"""
    # Get map config for the frontend
    map_config = get_map_api_config()
    # Get national emergency helplines
    helplines = get_india_emergency_helplines()
    
    return render_template('india_map.html', 
                          map_config=json.dumps(map_config),
                          helplines=helplines)

@app.route('/api/india/geocode', methods=['POST'])
def india_geocode():
    """Convert address to coordinates using MapmyIndia geocoding"""
    data = request.get_json()
    address = data.get('address')
    
    if not address:
        return jsonify({'error': 'Address is required'}), 400
        
    result = geocode_address(address)
    return jsonify(result if result else {'error': 'Geocoding failed'})

@app.route('/api/india/reverse-geocode')
def india_reverse_geocode():
    """Convert coordinates to address using MapmyIndia reverse geocoding"""
    lat = request.args.get('lat', type=float)
    lng = request.args.get('lng', type=float)
    
    if not all([lat, lng]):
        return jsonify({'error': 'Latitude and longitude are required'}), 400
        
    result = reverse_geocode(lat, lng)
    return jsonify(result if result else {'error': 'Reverse geocoding failed'})

@app.route('/api/india/safe-route', methods=['POST'])
def india_safe_route():
    """Get a safe route using MapmyIndia routing API"""
    data = request.get_json()
    start_lat = data.get('start_lat')
    start_lng = data.get('start_lng')
    end_lat = data.get('end_lat')
    end_lng = data.get('end_lng')
    
    if not all([start_lat, start_lng, end_lat, end_lng]):
        return jsonify({'error': 'Start and end coordinates are required'}), 400
        
    result = get_safe_route(start_lat, start_lng, end_lat, end_lng)
    return jsonify(result if result else {'error': 'Route calculation failed'})

@app.route('/api/india/nearby-resources')
def india_nearby_resources():
    """Find nearby safety resources using MapmyIndia nearby API"""
    lat = request.args.get('lat', type=float)
    lng = request.args.get('lng', type=float)
    keyword = request.args.get('type')
    radius = request.args.get('radius', default=5000, type=int)  # meters
    
    if not all([lat, lng]):
        return jsonify({'error': 'Latitude and longitude are required'}), 400
        
    resources = find_nearby_safety_resources(lat, lng, keyword, radius)
    return jsonify({'resources': resources})

@app.route('/api/india/states')
def india_states():
    """Get list of Indian states"""
    return jsonify({'states': get_india_states()})

@app.route('/api/india/helplines')
def india_helplines():
    """Get list of emergency helplines for India"""
    return jsonify({'helplines': get_india_emergency_helplines()})

# MongoDB NoSQL API endpoints
@app.route('/api/incidents', methods=['POST'])
@login_required
def add_incident():
    """Add a safety incident to MongoDB"""
    data = request.get_json()
    
    # Make sure required fields are present
    required_fields = ['title', 'description', 'incident_type', 'latitude', 'longitude']
    if not all(field in data for field in required_fields):
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Add user information
    data['user_id'] = current_user.id
    data['username'] = current_user.username if not data.get('is_anonymous', False) else 'Anonymous'
    data['timestamp'] = datetime.utcnow()
    
    # Store in MongoDB
    result = database.save_safety_incident(data)
    
    if result:
        # Also add to SQL database for compatibility with existing features
        try:
            report = CommunityReport(
                user_id=current_user.id,
                title=data['title'],
                description=data['description'],
                incident_type=data['incident_type'],
                latitude=data['latitude'],
                longitude=data['longitude'],
                location_name=data.get('location_name'),
                is_anonymous=data.get('is_anonymous', False),
                state=data.get('state'),
                district=data.get('district'),
                city=data.get('city'),
                pincode=data.get('pincode'),
                severity=data.get('severity', 3)
            )
            db.session.add(report)
            db.session.commit()
        except Exception as e:
            # If SQL insert fails, we still have the MongoDB record
            app.logger.error(f"Failed to add incident to SQL: {e}")
        
        return jsonify({'success': True, 'id': result})
    else:
        return jsonify({'error': 'Failed to save incident'}), 500

@app.route('/api/incidents')
def get_incidents():
    """Get safety incidents from MongoDB with filtering options"""
    # Location filter
    lat = request.args.get('lat', type=float)
    lng = request.args.get('lng', type=float)
    radius_km = request.args.get('radius', default=5, type=float)
    
    # Time filter
    days = request.args.get('days', default=30, type=int)
    
    # Type filter
    incident_type = request.args.get('type')
    
    # Pagination
    limit = request.args.get('limit', default=50, type=int)
    
    # If location provided, do geospatial query
    if lat and lng:
        incidents = database.get_safety_incidents_by_location(lat, lng, radius_km, limit)
    else:
        # Build query
        query = {}
        
        # Filter by type if provided
        if incident_type:
            query['incident_type'] = incident_type
            
        # Filter by date if specified
        if days > 0:
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            query['timestamp'] = {'$gte': cutoff_date}
            
        incidents = database.get_safety_incidents(query, limit)
    
    return jsonify({'incidents': incidents})

@app.route('/api/incidents/stats')
def get_incident_stats():
    """Get aggregated statistics about safety incidents"""
    # Area filter
    state = request.args.get('state')
    district = request.args.get('district')
    city = request.args.get('city')
    
    # Build query based on area filter
    query = {}
    if state:
        query['state'] = state
    if district:
        query['district'] = district
    if city:
        query['city'] = city
        
    # Group by parameter (district, city, etc.)
    group_by = request.args.get('group_by', 'district')
    
    # Get stats
    stats = database.aggregate_safety_stats_by_area(query, group_by)
    
    return jsonify({'stats': stats})

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500
