import math
from geopy.distance import geodesic
import requests
import os

def calculate_distance(lat1, lon1, lat2, lon2):
    """
    Calculate the distance between two coordinates using the Haversine formula
    Args:
        lat1, lon1: Coordinates of first point
        lat2, lon2: Coordinates of second point
    Returns:
        Distance in kilometers
    """
    return geodesic((lat1, lon1), (lat2, lon2)).kilometers

def sort_by_distance(locations, reference_lat, reference_lng):
    """
    Sort a list of locations by distance from a reference point
    Args:
        locations: List of location objects with latitude and longitude attributes
        reference_lat: Reference latitude
        reference_lng: Reference longitude
    Returns:
        Sorted list of locations
    """
    # Calculate distance for each location
    for location in locations:
        location.distance = calculate_distance(
            reference_lat, reference_lng, 
            location.latitude, location.longitude
        )
    
    # Sort by distance
    return sorted(locations, key=lambda x: x.distance)

def get_address_from_coordinates(lat, lng):
    """
    Get address from coordinates using reverse geocoding
    Args:
        lat: Latitude
        lng: Longitude
    Returns:
        Address string or None if geocoding fails
    """
    try:
        # Use a geocoding service like OpenStreetMap's Nominatim
        # Note: For production, consider using a paid API with higher rate limits
        response = requests.get(
            f"https://nominatim.openstreetmap.org/reverse",
            params={
                "lat": lat,
                "lon": lng,
                "format": "json",
                "addressdetails": 1
            },
            headers={"User-Agent": "WomenSafetyApp/1.0"}
        )
        
        if response.status_code == 200:
            data = response.json()
            if "display_name" in data:
                return data["display_name"]
        
        return None
    except Exception as e:
        print(f"Error in reverse geocoding: {e}")
        return None

def get_coordinates_from_address(address):
    """
    Get coordinates from address using forward geocoding
    Args:
        address: Address string
    Returns:
        (latitude, longitude) tuple or None if geocoding fails
    """
    try:
        # Use a geocoding service like OpenStreetMap's Nominatim
        response = requests.get(
            f"https://nominatim.openstreetmap.org/search",
            params={
                "q": address,
                "format": "json",
                "limit": 1
            },
            headers={"User-Agent": "WomenSafetyApp/1.0"}
        )
        
        if response.status_code == 200:
            data = response.json()
            if data and len(data) > 0:
                return (float(data[0]["lat"]), float(data[0]["lon"]))
        
        return None
    except Exception as e:
        print(f"Error in forward geocoding: {e}")
        return None

def find_nearby_safety_resources(lat, lng, resource_type=None, radius_km=5):
    """
    Find nearby safety resources (police stations, hospitals, etc.)
    This would typically use an API like Google Places or OpenStreetMap's Overpass API
    
    Args:
        lat: Latitude
        lng: Longitude
        resource_type: Type of resource to search for (police, hospital, etc.)
        radius_km: Search radius in kilometers
    
    Returns:
        List of resources in the specified radius
    """
    try:
        # For this implementation, we'll use OpenStreetMap's Overpass API
        # In a production app, you might want to use a different service with higher rate limits
        
        # Build the query
        amenity_type = "police" if resource_type == "police" else \
                      "hospital" if resource_type == "hospital" else \
                      "shelter" if resource_type == "shelter" else \
                      "police|hospital|shelter"  # Default to all safety resources
        
        # Convert radius to meters
        radius_m = radius_km * 1000
        
        # Build Overpass API query
        query = f"""
        [out:json];
        (
          node["amenity"~"{amenity_type}"](around:{radius_m},{lat},{lng});
          way["amenity"~"{amenity_type}"](around:{radius_m},{lat},{lng});
          relation["amenity"~"{amenity_type}"](around:{radius_m},{lat},{lng});
        );
        out center;
        """
        
        response = requests.post(
            "https://overpass-api.de/api/interpreter",
            data={"data": query},
            headers={"User-Agent": "WomenSafetyApp/1.0"}
        )
        
        if response.status_code == 200:
            data = response.json()
            resources = []
            
            for element in data.get("elements", []):
                resource = {
                    "type": element.get("tags", {}).get("amenity", "unknown"),
                    "name": element.get("tags", {}).get("name", "Unnamed"),
                    "latitude": element.get("lat") or element.get("center", {}).get("lat"),
                    "longitude": element.get("lon") or element.get("center", {}).get("lon"),
                    "address": None,
                    "phone": element.get("tags", {}).get("phone"),
                }
                
                # Calculate distance
                if resource["latitude"] and resource["longitude"]:
                    resource["distance"] = calculate_distance(
                        lat, lng, resource["latitude"], resource["longitude"]
                    )
                    resources.append(resource)
            
            # Sort by distance
            return sorted(resources, key=lambda x: x.get("distance", float('inf')))
        
        return []
    except Exception as e:
        print(f"Error finding nearby safety resources: {e}")
        return []
