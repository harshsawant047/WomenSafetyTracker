import requests
import json
import logging
import math
import random
from services import crime_data, safety_model

def get_route(start_coords, end_coords):
    """
    Get a route between two points using OpenStreetMap's routing API
    
    Args:
        start_coords: (lat, lng) tuple for start point
        end_coords: (lat, lng) tuple for end point
        
    Returns:
        Dictionary with route information
    """
    try:
        # Use OpenStreetMap's OSRM API for routing
        # Note: For production, consider using a paid API with higher rate limits
        url = "https://router.project-osrm.org/route/v1/foot/{},{};{},{}".format(
            start_coords[1], start_coords[0],  # OSRM expects lon,lat format
            end_coords[1], end_coords[0]
        )
        
        params = {
            "overview": "full",
            "geometries": "geojson",
            "steps": "true"
        }
        
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            
            if data["code"] == "Ok" and len(data["routes"]) > 0:
                route = data["routes"][0]
                
                # Extract the route geometry
                geometry = route["geometry"]
                
                # Extract step-by-step instructions
                steps = []
                for leg in route["legs"]:
                    for step in leg["steps"]:
                        steps.append({
                            "instruction": step["maneuver"]["type"],
                            "distance": step["distance"],
                            "duration": step["duration"]
                        })
                
                return {
                    "distance": route["distance"],
                    "duration": route["duration"],
                    "geometry": geometry,
                    "steps": steps
                }
        
        # If API call failed or returned no routes
        return {
            "error": "No route found",
            "status": response.status_code if response else "No response"
        }
    
    except Exception as e:
        logging.error(f"Error getting route: {e}")
        return {
            "error": f"Error getting route: {str(e)}"
        }

def get_safe_route(start_coords, end_coords):
    """
    Get a safer route between two points, considering crime data
    
    Args:
        start_coords: (lat, lng) tuple for start point
        end_coords: (lat, lng) tuple for end point
        
    Returns:
        Dictionary with route information, including safety score
    """
    try:
        # Get the standard route first
        standard_route = get_route(start_coords, end_coords)
        
        if "error" in standard_route:
            return standard_route
        
        # Get crime data along the route
        route_points = standard_route["geometry"]["coordinates"]
        
        # Convert from [lon, lat] to [lat, lon]
        route_points = [[point[1], point[0]] for point in route_points]
        
        # Sample points along the route to check for safety
        # For a long route, we don't need to check every point
        sample_step = max(1, len(route_points) // 10)  # Check about 10 points
        sample_points = route_points[::sample_step]
        
        # Check safety score for each sample point
        safety_scores = []
        for point in sample_points:
            lat, lng = point
            risk_info = safety_model.calculate_area_risk_score(lat, lng, radius_km=0.5)
            safety_scores.append({
                "latitude": lat,
                "longitude": lng,
                "risk_score": risk_info["score"],
                "risk_level": risk_info["level"]
            })
        
        # Calculate overall safety score for the route
        if safety_scores:
            avg_risk_score = sum(s["risk_score"] for s in safety_scores) / len(safety_scores)
            max_risk_score = max(s["risk_score"] for s in safety_scores)
            
            # Determine overall risk level
            if avg_risk_score < 25:
                risk_level = "low"
            elif avg_risk_score < 50:
                risk_level = "medium"
            elif avg_risk_score < 75:
                risk_level = "high"
            else:
                risk_level = "very high"
            
            # Add safety information to the route
            standard_route["safety"] = {
                "average_risk_score": avg_risk_score,
                "max_risk_score": max_risk_score,
                "risk_level": risk_level,
                "risk_points": safety_scores
            }
        
        # In a production app, we would attempt to find alternative safer routes here
        # For now, we'll just return the standard route with safety information
        
        return standard_route
    
    except Exception as e:
        logging.error(f"Error getting safe route: {e}")
        return {
            "error": f"Error calculating safe route: {str(e)}"
        }

def get_alternative_routes(start_coords, end_coords, max_alternatives=2):
    """
    Get multiple alternative routes between two points
    
    Args:
        start_coords: (lat, lng) tuple for start point
        end_coords: (lat, lng) tuple for end point
        max_alternatives: Maximum number of alternative routes to return
        
    Returns:
        List of route dictionaries with safety information
    """
    try:
        # Use OpenStreetMap's OSRM API for alternative routes
        url = "https://router.project-osrm.org/route/v1/foot/{},{};{},{}".format(
            start_coords[1], start_coords[0],  # OSRM expects lon,lat format
            end_coords[1], end_coords[0]
        )
        
        params = {
            "overview": "full",
            "geometries": "geojson",
            "steps": "true",
            "alternatives": "true"
        }
        
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            
            if data["code"] == "Ok" and data["routes"]:
                routes = []
                
                for i, route_data in enumerate(data["routes"][:max_alternatives + 1]):
                    # Extract the route geometry
                    geometry = route_data["geometry"]
                    
                    # Convert from [lon, lat] to [lat, lon]
                    route_points = [[point[1], point[0]] for point in geometry["coordinates"]]
                    
                    # Sample points along the route to check for safety
                    sample_step = max(1, len(route_points) // 10)
                    sample_points = route_points[::sample_step]
                    
                    # Check safety score for each sample point
                    safety_scores = []
                    for point in sample_points:
                        lat, lng = point
                        risk_info = safety_model.calculate_area_risk_score(lat, lng, radius_km=0.5)
                        safety_scores.append({
                            "latitude": lat,
                            "longitude": lng,
                            "risk_score": risk_info["score"],
                            "risk_level": risk_info["level"]
                        })
                    
                    # Calculate overall safety score for the route
                    if safety_scores:
                        avg_risk_score = sum(s["risk_score"] for s in safety_scores) / len(safety_scores)
                        max_risk_score = max(s["risk_score"] for s in safety_scores)
                        
                        # Determine overall risk level
                        if avg_risk_score < 25:
                            risk_level = "low"
                        elif avg_risk_score < 50:
                            risk_level = "medium"
                        elif avg_risk_score < 75:
                            risk_level = "high"
                        else:
                            risk_level = "very high"
                    else:
                        avg_risk_score = 50  # Default medium risk
                        max_risk_score = 50
                        risk_level = "medium"
                    
                    # Extract step-by-step instructions
                    steps = []
                    for leg in route_data["legs"]:
                        for step in leg["steps"]:
                            steps.append({
                                "instruction": step["maneuver"]["type"],
                                "distance": step["distance"],
                                "duration": step["duration"]
                            })
                    
                    routes.append({
                        "route_id": i,
                        "distance": route_data["distance"],
                        "duration": route_data["duration"],
                        "geometry": geometry,
                        "steps": steps,
                        "safety": {
                            "average_risk_score": avg_risk_score,
                            "max_risk_score": max_risk_score,
                            "risk_level": risk_level,
                            "risk_points": safety_scores
                        }
                    })
                
                # Sort routes by safety score (ascending)
                routes.sort(key=lambda r: r["safety"]["average_risk_score"])
                
                return routes
        
        # If API call failed or returned no routes
        return [{
            "error": "No alternative routes found",
            "status": response.status_code if response else "No response"
        }]
    
    except Exception as e:
        logging.error(f"Error getting alternative routes: {e}")
        return [{
            "error": f"Error calculating alternative routes: {str(e)}"
        }]
