import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import pickle
import os
import joblib
from datetime import datetime

# Predefined list of cities with safety ratings
# In a production environment, this would be replaced with an actual ML model
CITY_SAFETY_DATA = {
    'New York': {'safety_score': 75, 'classification': 'safe', 'crime_rate': 'medium', 
                'common_crimes': ['theft', 'assault'], 'safe_areas': ['Manhattan', 'Brooklyn Heights']},
    'Chicago': {'safety_score': 65, 'classification': 'moderate', 'crime_rate': 'high', 
               'common_crimes': ['theft', 'robbery'], 'safe_areas': ['Lincoln Park', 'Lake View']},
    'Los Angeles': {'safety_score': 70, 'classification': 'moderate', 'crime_rate': 'medium', 
                  'common_crimes': ['vehicle theft', 'burglary'], 'safe_areas': ['Santa Monica', 'Beverly Hills']},
    'Houston': {'safety_score': 60, 'classification': 'moderate', 'crime_rate': 'high', 
               'common_crimes': ['theft', 'assault'], 'safe_areas': ['The Woodlands', 'Sugar Land']},
    'Phoenix': {'safety_score': 65, 'classification': 'moderate', 'crime_rate': 'medium', 
               'common_crimes': ['theft', 'car theft'], 'safe_areas': ['Scottsdale', 'Paradise Valley']},
    'Philadelphia': {'safety_score': 60, 'classification': 'moderate', 'crime_rate': 'high', 
                    'common_crimes': ['theft', 'robbery'], 'safe_areas': ['Chestnut Hill', 'Old City']},
    'San Antonio': {'safety_score': 70, 'classification': 'moderate', 'crime_rate': 'medium', 
                   'common_crimes': ['theft', 'burglary'], 'safe_areas': ['Stone Oak', 'Alamo Heights']},
    'San Diego': {'safety_score': 80, 'classification': 'safe', 'crime_rate': 'low', 
                 'common_crimes': ['theft', 'vandalism'], 'safe_areas': ['La Jolla', 'Del Mar']},
    'Dallas': {'safety_score': 65, 'classification': 'moderate', 'crime_rate': 'medium', 
              'common_crimes': ['theft', 'assault'], 'safe_areas': ['Highland Park', 'University Park']},
    'San Francisco': {'safety_score': 70, 'classification': 'moderate', 'crime_rate': 'medium', 
                     'common_crimes': ['theft', 'car break-ins'], 'safe_areas': ['Marina District', 'Noe Valley']},
    'Seattle': {'safety_score': 75, 'classification': 'safe', 'crime_rate': 'medium', 
               'common_crimes': ['property crime', 'car theft'], 'safe_areas': ['Queen Anne', 'Ballard']},
    'Boston': {'safety_score': 80, 'classification': 'safe', 'crime_rate': 'low', 
              'common_crimes': ['theft', 'burglary'], 'safe_areas': ['Back Bay', 'Beacon Hill']},
    'Denver': {'safety_score': 75, 'classification': 'safe', 'crime_rate': 'medium', 
              'common_crimes': ['theft', 'property crime'], 'safe_areas': ['Washington Park', 'Cherry Creek']},
    'Washington DC': {'safety_score': 70, 'classification': 'moderate', 'crime_rate': 'medium', 
                     'common_crimes': ['theft', 'assault'], 'safe_areas': ['Georgetown', 'Foggy Bottom']},
    'Atlanta': {'safety_score': 60, 'classification': 'moderate', 'crime_rate': 'high', 
               'common_crimes': ['theft', 'car theft'], 'safe_areas': ['Buckhead', 'Midtown']},
}

def get_available_cities():
    """
    Get list of cities available for safety prediction
    """
    return sorted(list(CITY_SAFETY_DATA.keys()))

def predict_city_safety(city_name):
    """
    Predict safety score and classification for a given city
    In a production environment, this would use an actual trained ML model
    
    Args:
        city_name: Name of the city
        
    Returns:
        Dictionary with safety information or None if city not found
    """
    if city_name in CITY_SAFETY_DATA:
        return CITY_SAFETY_DATA[city_name]
    
    # If city not in our database, return a default response
    return {
        'safety_score': None,
        'classification': 'unknown',
        'crime_rate': 'unknown',
        'common_crimes': [],
        'safe_areas': [],
        'message': f"Sorry, we don't have enough data for {city_name} yet."
    }

def calculate_area_risk_score(lat, lng, radius_km=1):
    """
    Calculate a risk score for a specific area based on crime data
    
    Args:
        lat: Latitude
        lng: Longitude
        radius_km: Radius in kilometers
        
    Returns:
        Risk score (0-100, higher is more risky)
    """
    from services import crime_data
    
    # Get nearby crime data
    crimes = crime_data.get_nearby_crime_data(lat, lng, radius_km)
    
    if not crimes:
        return {
            'score': 25,  # Default low-medium risk when no data is available
            'level': 'low-medium',
            'crime_count': 0,
            'message': 'No crime data available for this area. Exercise normal caution.'
        }
    
    # Calculate basic risk score based on crime count and severity
    crime_count = len(crimes)
    
    # Calculate average severity (if available)
    avg_severity = sum(c.get('severity', 1) for c in crimes) / crime_count if crime_count > 0 else 1
    
    # Weight more recent crimes higher
    # This would need actual date parsing in a production environment
    recent_weight = 1.0  # Simplified for this implementation
    
    # Calculate base risk score (0-100)
    # This formula would be refined based on actual crime statistics in production
    base_score = min(100, (crime_count * avg_severity * recent_weight * 5))
    
    # Determine risk level
    if base_score < 25:
        risk_level = 'low'
        message = 'This area appears to have low risk based on historical data.'
    elif base_score < 50:
        risk_level = 'medium'
        message = 'This area has a medium risk level. Exercise standard caution.'
    elif base_score < 75:
        risk_level = 'high'
        message = 'This area has a high risk level. Stay vigilant and avoid isolated areas.'
    else:
        risk_level = 'very high'
        message = 'This area has a very high risk level. Consider avoiding or use extreme caution.'
    
    # Common crime types in the area
    crime_types = {}
    for crime in crimes:
        crime_type = crime.get('type', 'Unknown')
        crime_types[crime_type] = crime_types.get(crime_type, 0) + 1
    
    # Sort crime types by frequency
    common_crimes = sorted(crime_types.items(), key=lambda x: x[1], reverse=True)
    
    return {
        'score': base_score,
        'level': risk_level,
        'crime_count': crime_count,
        'common_crimes': [c[0] for c in common_crimes[:3]],  # Top 3 most common crimes
        'message': message
    }

def train_safety_model():
    """
    Train a machine learning model for predicting area safety
    This is a placeholder function that would be implemented in a production environment
    """
    # In a real application, this would:
    # 1. Load historical crime data
    # 2. Engineer features (crime rates, time patterns, etc.)
    # 3. Train a classification model (e.g., Random Forest)
    # 4. Save the model for future predictions
    
    # Example placeholder implementation
    try:
        # Create a simple model directory if it doesn't exist
        os.makedirs('models', exist_ok=True)
        
        # Create a dummy model (Random Forest with minimal features)
        model = RandomForestClassifier(n_estimators=100, random_state=42)
        
        # In a real application, we'd fit this model on actual data
        # For now, we'll just save the untrained model
        model_path = os.path.join('models', 'safety_model.pkl')
        joblib.dump(model, model_path)
        
        return True
    except Exception as e:
        print(f"Error training safety model: {e}")
        return False
