import os
import requests
import json
import logging

# Fast2SMS API key
FAST2SMS_API_KEY = "6adj3zgxAdWoSWjdBZmWFvvHMIJvMagBHGRRz12vJhkg4k4kjokPl64BBMsH"

# Whether to use the real API or fallback
USE_REAL_API = True  # Set to True to use the real Fast2SMS API

def send_sms(phone_number, message):
    """
    Send SMS using Fast2SMS API
    
    Args:
        phone_number: Recipient's phone number (string)
        message: SMS message content (string)
        
    Returns:
        Dictionary with status and message
    """
    # Format phone number (remove any non-digit characters)
    phone_number = ''.join(filter(str.isdigit, phone_number))
    
    # Ensure phone number is valid
    if not phone_number or len(phone_number) < 10:
        return {"status": "error", "message": "Invalid phone number"}
    
    # Check if we're using the real API or simulation mode
    if not USE_REAL_API:
        # Simulation mode - log the message but don't actually send it
        logging.info(f"SIMULATION MODE: Would send SMS to {phone_number}: {message}")
        return {
            "status": "success", 
            "message": "SMS sent successfully (SIMULATION MODE)",
            "details": {
                "simulation": True,
                "phone": phone_number,
                "message_length": len(message)
            }
        }
        
    # Real API mode
    if not FAST2SMS_API_KEY:
        logging.error("Fast2SMS API key not set in environment variables")
        return {"status": "error", "message": "SMS API key not configured"}
    
    url = "https://www.fast2sms.com/dev/bulkV2"
    
    payload = {
        "route": "q",  # Quick SMS (transactional message)
        "message": message,
        "language": "english",
        "flash": 0,
        "numbers": phone_number
    }
    
    headers = {
        "authorization": FAST2SMS_API_KEY,
        "Content-Type": "application/json",
        "Cache-Control": "no-cache"
    }
    
    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload))
        json_response = response.json()
        
        if response.status_code == 200 and json_response.get("return") is True:
            return {
                "status": "success", 
                "message": "SMS sent successfully",
                "details": json_response
            }
        else:
            logging.error(f"Fast2SMS API error: {json_response}")
            return {
                "status": "error", 
                "message": "Failed to send SMS",
                "details": json_response
            }
    
    except Exception as e:
        logging.error(f"Error sending SMS: {e}")
        return {"status": "error", "message": f"Error sending SMS: {str(e)}"}

def send_emergency_sms(phone_number, user_name, location_info, coordinates):
    """
    Send emergency SOS message to an emergency contact
    
    Args:
        phone_number: Emergency contact's phone number
        user_name: Name of the user sending SOS
        location_info: Location description (address or place name)
        coordinates: [latitude, longitude] coordinates
        
    Returns:
        Dictionary with status and message
    """
    # Create SOS message
    message = f"EMERGENCY SOS from {user_name}. They need immediate help! "
    
    if location_info:
        message += f"Location: {location_info}. "
    
    if coordinates and len(coordinates) == 2:
        message += f"GPS: {coordinates[0]:.6f},{coordinates[1]:.6f}"
        # Add Google Maps link to make it easier for the contact to find the location
        message += f" https://maps.google.com/?q={coordinates[0]:.6f},{coordinates[1]:.6f}"
    
    # Send the SMS
    return send_sms(phone_number, message)