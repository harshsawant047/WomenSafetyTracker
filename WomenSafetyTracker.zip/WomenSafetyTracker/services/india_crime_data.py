import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta
import json

# State coordinates (approximate centers)
STATE_COORDINATES = {
    'ANDHRA PRADESH': [15.9129, 79.7400],
    'ARUNACHAL PRADESH': [28.2180, 94.7278],
    'ASSAM': [26.2006, 92.9376],
    'BIHAR': [25.0961, 85.3131],
    'CHHATTISGARH': [21.2787, 81.8661],
    'GOA': [15.2993, 74.1240],
    'GUJARAT': [22.2587, 71.1924],
    'HARYANA': [29.0588, 76.0856],
    'HIMACHAL PRADESH': [31.1048, 77.1734],
    'JAMMU & KASHMIR': [33.7782, 76.5762],
    'JHARKHAND': [23.6102, 85.2799],
    'KARNATAKA': [15.3173, 75.7139],
    'KERALA': [10.8505, 76.2711],
    'MADHYA PRADESH': [23.4733, 77.9471],
    'MAHARASHTRA': [19.7515, 75.7139],
    'MANIPUR': [24.6637, 93.9063],
    'MEGHALAYA': [25.4670, 91.3662],
    'MIZORAM': [23.1645, 92.9376],
    'NAGALAND': [26.1584, 94.5624],
    'ODISHA': [20.9517, 85.0985],
    'PUNJAB': [31.1471, 75.3412],
    'RAJASTHAN': [27.0238, 74.2179],
    'SIKKIM': [27.5330, 88.5122],
    'TAMIL NADU': [11.1271, 78.6569],
    'TELANGANA': [18.1124, 79.0193],
    'TRIPURA': [23.9408, 91.9882],
    'UTTAR PRADESH': [26.8467, 80.9462],
    'UTTARAKHAND': [30.0668, 79.0193],
    'WEST BENGAL': [22.9868, 87.8550],
    'DELHI': [28.7041, 77.1025],
    'A & N ISLANDS': [11.7401, 92.6586],
    'CHANDIGARH': [30.7333, 76.7794],
    'D&N HAVELI': [20.1809, 73.0169],
    'DAMAN & DIU': [20.4283, 72.8397],
    'LAKSHADWEEP': [10.5667, 72.6417],
    'PUDUCHERRY': [11.9416, 79.8083]
}

def normalize_state_name(state_name):
    """Normalize state names for consistency"""
    state_name = state_name.upper().strip()
    # Convert state name variations
    if state_name == "ANDHRA PRADESH":
        return "ANDHRA PRADESH"
    if state_name == "DELHI UT":
        return "DELHI"
    if state_name == "JAMMU & KASHMIR":
        return "JAMMU & KASHMIR"
    if state_name == "D & N HAVELI":
        return "D&N HAVELI"
    if state_name == "A & N ISLANDS":
        return "A & N ISLANDS"
    # Default: return as is
    return state_name

def load_india_crime_data():
    """
    Load India crime data from the CSV files
    """
    try:
        # Load 2015 state-wise crimes data - first check in data/india directory
        state_data_path = os.path.join('data', 'india', 'State-wise_Crimes_committed_against_Women_2015_1.csv')
        if os.path.exists(state_data_path):
            state_df = pd.read_csv(state_data_path)
        else:
            # Fallback to attached_assets directory
            state_data_path = os.path.join('attached_assets', 'State-wise_Crimes_committed_against_Women_2015_1.csv')
            if os.path.exists(state_data_path):
                state_df = pd.read_csv(state_data_path)
            else:
                print(f"File not found: {state_data_path}")
                state_df = pd.DataFrame()
        
        # Load historical crime data - first check in data/india directory
        historical_data_path = os.path.join('data', 'india', 'CrimesOnWomenData.csv')
        if os.path.exists(historical_data_path):
            hist_df = pd.read_csv(historical_data_path)
        else:
            # Fallback to attached_assets directory
            historical_data_path = os.path.join('attached_assets', 'CrimesOnWomenData.csv')
            if os.path.exists(historical_data_path):
                hist_df = pd.read_csv(historical_data_path)
            else:
                print(f"File not found: {historical_data_path}")
                hist_df = pd.DataFrame()
            
        return {
            'state_data': state_df,
            'historical_data': hist_df
        }
    except Exception as e:
        print(f"Error loading India crime data: {e}")
        return {
            'state_data': pd.DataFrame(),
            'historical_data': pd.DataFrame()
        }

def get_india_heatmap_data():
    """
    Get crime data for heatmap visualization for Indian states
    Returns list of [lat, lng, intensity] points based on 2015 data
    """
    data = load_india_crime_data()
    state_df = data['state_data']
    
    if state_df.empty:
        return []
    
    # Calculate total crimes for each state
    heatmap_data = []
    
    for _, row in state_df.iterrows():
        # Extract state name
        state_name = row['State/ UT'] if 'State/ UT' in row else None
        if not state_name:
            continue
            
        # Normalize state name
        state_name = normalize_state_name(state_name)
        
        # Get total crimes (excluding the first 3 columns: State, Sl. No., District/Area, Year)
        total_crimes = row.iloc[4:].sum()
        
        # Get coordinates for the state
        coords = STATE_COORDINATES.get(state_name)
        if not coords:
            continue
            
        # Scale intensity based on number of crimes (enhanced logarithmic scale for better visualization)
        # Increased intensity factor from 2 to 5 to make heatmap more visible
        intensity = np.log1p(total_crimes) * 2
        
        heatmap_data.append([
            coords[0],  # latitude
            coords[1],  # longitude
            intensity   # intensity
        ])
    
    return heatmap_data

def get_india_risk_analysis():
    """
    Get risk analysis data for Indian states
    Returns state-wise safety scores and risk levels
    """
    data = load_india_crime_data()
    state_df = data['state_data']
    hist_df = data['historical_data']
    
    if state_df.empty:
        return []
    
    risk_data = []
    
    for _, row in state_df.iterrows():
        # Extract state name
        state_name = row['State/ UT'] if 'State/ UT' in row else None
        if not state_name:
            continue
            
        # Normalize state name
        state_name = normalize_state_name(state_name)
        
        # Get total crimes
        total_crimes = row.iloc[4:].sum()
        
        # Calculate safety score (inverse relationship with crime rate - higher score means safer)
        # Scale from 0-100 where 100 is safest
        max_crimes = state_df.iloc[:, 4:].sum(axis=1).max()
        safety_score = max(0, 100 - (total_crimes / max_crimes * 100))
        
        # Determine risk level
        if safety_score >= 80:
            risk_level = "Low"
            risk_class = "success"
        elif safety_score >= 60:
            risk_level = "Moderate"
            risk_class = "info"
        elif safety_score >= 40:
            risk_level = "Medium"
            risk_class = "warning"
        else:
            risk_level = "High"
            risk_class = "danger"
        
        # Find most common crime type
        crime_types = {
            'Rape': row['Rape'] if 'Rape' in row else 0,
            'Kidnapping': row['Kidnapping & Abduction_Total'] if 'Kidnapping & Abduction_Total' in row else 0, 
            'Dowry Deaths': row['Dowry Deaths'] if 'Dowry Deaths' in row else 0,
            'Assault': row['Assault on Women with intent to outrage her Modesty_Total'] if 'Assault on Women with intent to outrage her Modesty_Total' in row else 0,
            'Cruelty by Husband': row['Cruelty by Husband or his Relatives'] if 'Cruelty by Husband or his Relatives' in row else 0,
        }
        
        most_common_crime = max(crime_types.items(), key=lambda x: x[1])[0]
        
        # Get coordinates
        coords = STATE_COORDINATES.get(state_name, [0, 0])
        
        risk_data.append({
            'state': state_name.title(),
            'safety_score': round(safety_score, 1),
            'risk_level': risk_level,
            'risk_class': risk_class,
            'most_common_crime': most_common_crime,
            'total_crimes': int(total_crimes),
            'lat': coords[0],
            'lng': coords[1]
        })
    
    # Sort by safety score (highest first)
    risk_data.sort(key=lambda x: x['safety_score'], reverse=True)
    
    return risk_data

def get_india_crime_trend():
    """
    Get crime trend data for Indian states over years
    Returns data formatted for charts
    """
    data = load_india_crime_data()
    hist_df = data['historical_data']
    
    if hist_df.empty:
        return {}
    
    # Group by year and sum all crime types
    try:
        yearly_crimes = hist_df.groupby('Year').sum()
        
        # Extract relevant columns (crime types)
        crime_types = ['Rape', 'K&A', 'DD', 'AoW', 'AoM', 'DV', 'WT']
        
        # Prepare data for chart.js
        labels = yearly_crimes.index.astype(str).tolist()
        datasets = []
        
        crime_type_names = {
            'Rape': 'Rape',
            'K&A': 'Kidnapping & Abduction',
            'DD': 'Dowry Deaths',
            'AoW': 'Assault on Women',
            'AoM': 'Attack on Modesty',
            'DV': 'Domestic Violence',
            'WT': 'Women Trafficking'
        }
        
        colors = [
            'rgba(255, 99, 132, 0.6)',   # Red
            'rgba(54, 162, 235, 0.6)',   # Blue
            'rgba(255, 206, 86, 0.6)',   # Yellow
            'rgba(75, 192, 192, 0.6)',   # Green
            'rgba(153, 102, 255, 0.6)',  # Purple
            'rgba(255, 159, 64, 0.6)',   # Orange
            'rgba(199, 199, 199, 0.6)'   # Grey
        ]
        
        for i, crime_type in enumerate(crime_types):
            if crime_type in yearly_crimes.columns:
                datasets.append({
                    'label': crime_type_names.get(crime_type, crime_type),
                    'data': yearly_crimes[crime_type].tolist(),
                    'backgroundColor': colors[i % len(colors)],
                    'borderColor': colors[i % len(colors)].replace('0.6', '1.0'),
                    'borderWidth': 1
                })
        
        return {
            'labels': labels,
            'datasets': datasets
        }
    
    except Exception as e:
        print(f"Error processing crime trend data: {e}")
        return {
            'labels': [],
            'datasets': []
        }

def get_india_crime_distribution():
    """
    Get distribution of crime types in India
    Returns data formatted for pie/bar charts
    """
    data = load_india_crime_data()
    state_df = data['state_data']
    
    if state_df.empty:
        return {}
    
    try:
        # Extract crime types and their totals
        crime_totals = {
            'Rape': state_df['Rape'].sum() if 'Rape' in state_df.columns else 0,
            'Kidnapping & Abduction': state_df['Kidnapping & Abduction_Total'].sum() if 'Kidnapping & Abduction_Total' in state_df.columns else 0,
            'Dowry Deaths': state_df['Dowry Deaths'].sum() if 'Dowry Deaths' in state_df.columns else 0,
            'Assault on Women': state_df['Assault on Women with intent to outrage her Modesty_Total'].sum() if 'Assault on Women with intent to outrage her Modesty_Total' in state_df.columns else 0,
            'Insult to Modesty': state_df['Insult to the Modesty of Women_Total'].sum() if 'Insult to the Modesty of Women_Total' in state_df.columns else 0,
            'Cruelty by Husband': state_df['Cruelty by Husband or his Relatives'].sum() if 'Cruelty by Husband or his Relatives' in state_df.columns else 0,
            'Dowry Prohibition Act': state_df['Dowry Prohibition Act, 1961'].sum() if 'Dowry Prohibition Act, 1961' in state_df.columns else 0
        }
        
        # Remove zero values and convert NumPy values to native Python types
        crime_totals = {k: int(v) for k, v in crime_totals.items() if v > 0}
        
        # Sort by value (descending)
        crime_totals = dict(sorted(crime_totals.items(), key=lambda item: item[1], reverse=True))
        
        # Colors for chart
        colors = [
            'rgba(255, 99, 132, 0.6)',   # Red
            'rgba(54, 162, 235, 0.6)',   # Blue
            'rgba(255, 206, 86, 0.6)',   # Yellow
            'rgba(75, 192, 192, 0.6)',   # Green
            'rgba(153, 102, 255, 0.6)',  # Purple
            'rgba(255, 159, 64, 0.6)',   # Orange
            'rgba(199, 199, 199, 0.6)'   # Grey
        ]
        
        return {
            'labels': list(crime_totals.keys()),
            'datasets': [{
                'label': 'Crime Types',
                'data': list(crime_totals.values()),
                'backgroundColor': colors[:len(crime_totals)]
            }]
        }
        
    except Exception as e:
        print(f"Error processing crime distribution data: {e}")
        return {
            'labels': [],
            'datasets': []
        }

def get_state_crime_data(state_name):
    """
    Get detailed crime data for a specific state
    Args:
        state_name: Name of the state
    Returns:
        Dictionary with state crime information
    """
    data = load_india_crime_data()
    state_df = data['state_data']
    hist_df = data['historical_data']
    
    if state_df.empty:
        return {}
    
    try:
        # Normalize state name
        normalized_state = normalize_state_name(state_name)
        
        # Filter current data for the state
        state_row = state_df[state_df['State/ UT'] == normalized_state]
        
        if state_row.empty:
            return {}
        
        # Extract crime data
        state_crime_data = state_row.iloc[0].to_dict()
        
        # Get historical data for the state if available
        state_hist = hist_df[hist_df['State'] == normalized_state] if not hist_df.empty else pd.DataFrame()
        yearly_trend = {}
        
        if not state_hist.empty:
            years = state_hist['Year'].unique()
            for crime_type in ['Rape', 'K&A', 'DD', 'AoW', 'AoM', 'DV', 'WT']:
                if crime_type in state_hist.columns:
                    yearly_trend[crime_type] = [
                        state_hist[state_hist['Year'] == year][crime_type].sum()
                        for year in years
                    ]
            
            # Add years to the data
            yearly_trend['years'] = years.tolist()
        
        # Calculate safety score (inverse relationship with crime rate)
        total_crimes = state_row.iloc[:, 4:].sum(axis=1).values[0]
        max_crimes = state_df.iloc[:, 4:].sum(axis=1).max()
        safety_score = max(0, 100 - (total_crimes / max_crimes * 100))
        
        # Get coordinates
        coords = STATE_COORDINATES.get(normalized_state, [0, 0])
        
        return {
            'state_name': state_name,
            'crime_data': state_crime_data,
            'yearly_trend': yearly_trend,
            'safety_score': round(safety_score, 1),
            'total_crimes': int(total_crimes),
            'lat': coords[0],
            'lng': coords[1]
        }
        
    except Exception as e:
        print(f"Error processing state crime data: {e}")
        return {}