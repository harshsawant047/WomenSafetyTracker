import os
import json
import logging
from datetime import datetime
from app import db
from models import EmergencyContact, User
from services.fast2sms import send_emergency_sms

# In a production application, this would use a real SMS/notification service
def send_sos_alerts(user_id, latitude, longitude):
    """
    Send SOS alerts to user's emergency contacts
    
    Args:
        user_id: ID of the user sending the SOS
        latitude: Current latitude
        longitude: Current longitude
        
    Returns:
        Dictionary with status and message
    """
    try:
        # Get user information
        user = User.query.get(user_id)
        if not user:
            return {
                'status': 'error',
                'message': 'User not found'
            }
        
        # Get user's emergency contacts
        contacts = EmergencyContact.query.filter_by(user_id=user_id).all()
        if not contacts:
            return {
                'status': 'error',
                'message': 'No emergency contacts found'
            }
        
        # Generate Google Maps link for the location
        maps_link = f"https://www.google.com/maps?q={latitude},{longitude}"
        
        # Current timestamp
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Prepare the SOS message
        sos_message = (
            f"EMERGENCY ALERT: {user.first_name or user.username} needs help! "
            f"Last known location at {timestamp}: {maps_link}"
        )
        
        # Log the SOS attempt for debugging
        logging.info(f"SOS triggered by user {user_id} at {timestamp} from {latitude}, {longitude}")
        
        # In a production app, this would send actual SMS or notifications
        # For now, we'll just simulate the process and return success
        
        # Send SMS to emergency contacts using Fast2SMS
        notified_contacts = []
        for contact in contacts:
            # Get user location info - attempt to use address components if available
            location_info = ""
            if user.city:
                location_info = f"{user.city}"
                if user.state:
                    location_info += f", {user.state}"
            
            # Send the emergency SMS
            sms_result = send_emergency_sms(
                contact.phone_number,
                user.first_name or user.username,
                location_info,
                [latitude, longitude]
            )
            
            logging.info(f"SMS to {contact.name} ({contact.phone_number}): {sms_result}")
            
            notified_contacts.append({
                'name': contact.name,
                'phone': contact.phone_number,
                'status': sms_result.get('status')
            })
        
        return {
            'status': 'success',
            'message': f'SOS alert sent to {len(notified_contacts)} contacts',
            'notified_contacts': notified_contacts,
            'timestamp': timestamp,
            'location': {
                'latitude': latitude,
                'longitude': longitude,
                'maps_link': maps_link
            }
        }
    
    except Exception as e:
        logging.error(f"Error sending SOS alerts: {e}")
        return {
            'status': 'error',
            'message': f'Failed to send SOS alerts: {str(e)}'
        }

def check_offline_sos_queue():
    """
    Check for any queued SOS messages that were generated offline
    and try to send them now that the device is back online
    
    In a production app, this would be part of a background task or worker
    """
    try:
        # Path where offline SOS messages would be stored
        queue_path = os.path.join('data', 'offline_sos_queue.json')
        
        if not os.path.exists(queue_path):
            return {
                'status': 'success',
                'message': 'No offline SOS messages in queue'
            }
        
        # Load queued messages
        with open(queue_path, 'r') as file:
            queued_messages = json.load(file)
        
        if not queued_messages:
            return {
                'status': 'success',
                'message': 'No offline SOS messages in queue'
            }
        
        # Process each queued message
        results = []
        messages_to_keep = []
        
        for message in queued_messages:
            # Try to send the SOS alert
            result = send_sos_alerts(
                message['user_id'],
                message['latitude'],
                message['longitude']
            )
            
            if result['status'] == 'success':
                results.append({
                    'original_timestamp': message['timestamp'],
                    'result': 'sent'
                })
            else:
                # Keep failed messages in the queue
                messages_to_keep.append(message)
                results.append({
                    'original_timestamp': message['timestamp'],
                    'result': 'failed'
                })
        
        # Update the queue with only failed messages
        with open(queue_path, 'w') as file:
            json.dump(messages_to_keep, file)
        
        return {
            'status': 'success',
            'message': f'Processed {len(queued_messages)} offline SOS messages',
            'results': results,
            'remaining_queued': len(messages_to_keep)
        }
    
    except Exception as e:
        logging.error(f"Error processing offline SOS queue: {e}")
        return {
            'status': 'error',
            'message': f'Failed to process offline SOS queue: {str(e)}'
        }

def queue_offline_sos(user_id, latitude, longitude):
    """
    Queue an SOS message for later delivery when device is offline
    
    Args:
        user_id: ID of the user sending the SOS
        latitude: Current latitude
        longitude: Current longitude
        
    Returns:
        Dictionary with status and message
    """
    try:
        # Ensure data directory exists
        os.makedirs('data', exist_ok=True)
        
        # Path for offline SOS queue
        queue_path = os.path.join('data', 'offline_sos_queue.json')
        
        # Load existing queue or create new one
        queued_messages = []
        if os.path.exists(queue_path):
            with open(queue_path, 'r') as file:
                queued_messages = json.load(file)
        
        # Add new message to queue
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        queued_messages.append({
            'user_id': user_id,
            'latitude': latitude,
            'longitude': longitude,
            'timestamp': timestamp
        })
        
        # Save updated queue
        with open(queue_path, 'w') as file:
            json.dump(queued_messages, file)
        
        return {
            'status': 'success',
            'message': 'SOS message queued for delivery when back online',
            'timestamp': timestamp
        }
    
    except Exception as e:
        logging.error(f"Error queuing offline SOS: {e}")
        return {
            'status': 'error',
            'message': f'Failed to queue offline SOS: {str(e)}'
        }
