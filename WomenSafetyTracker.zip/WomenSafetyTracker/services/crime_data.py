import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta
import random

def load_crime_data():
    """
    Load crime data from CSV file
    If production data is available, this would connect to an actual database
    """
    try:
        csv_path = os.path.join('data', 'sample_crime_data.csv')
        if os.path.exists(csv_path):
            return pd.read_csv(csv_path)
        else:
            # Return a structured empty DataFrame that matches expected schema
            return pd.DataFrame(columns=[
                'id', 'type', 'description', 'date', 'time', 
                'latitude', 'longitude', 'location', 'severity'
            ])
    except Exception as e:
        print(f"Error loading crime data: {e}")
        return pd.DataFrame()  # Return empty DataFrame on error

def get_crime_heatmap_data():
    """
    Get crime data for heatmap visualization
    Returns list of [lat, lng, intensity] points
    """
    df = load_crime_data()
    
    if df.empty:
        return []
    
    # Filter for recent crimes (e.g., last 6 months)
    # This assumes 'date' is in a recognizable date format
    if 'date' in df.columns:
        try:
            df['date'] = pd.to_datetime(df['date'])
            six_months_ago = datetime.now() - timedelta(days=180)
            df = df[df['date'] > six_months_ago]
        except:
            # If date parsing fails, use all data
            pass
    
    # Prepare heatmap data
    heatmap_data = []
    
    for _, row in df.iterrows():
        # Weight (intensity) could be based on severity or type
        weight = 1
        if 'severity' in df.columns:
            weight = row['severity'] if not pd.isna(row['severity']) else 1
        
        heatmap_data.append([
            row['latitude'],
            row['longitude'],
            weight
        ])
    
    return heatmap_data

def get_nearby_crime_data(lat, lng, radius_km=1):
    """
    Get crime data near a specific location
    Args:
        lat: latitude
        lng: longitude
        radius_km: radius in kilometers
    Returns:
        List of crime data points within the radius
    """
    df = load_crime_data()
    
    if df.empty:
        return []
    
    # Simple distance calculation (not accounting for Earth's curvature)
    # For a production app, use a proper spatial query or Haversine formula
    
    # Convert radius from km to degrees (approximate)
    radius_deg = radius_km / 111.0  # 1 degree is approx 111 km
    
    # Filter crimes within the radius
    nearby_crimes = []
    
    for _, row in df.iterrows():
        # Calculate distance
        dist = np.sqrt((row['latitude'] - lat)**2 + (row['longitude'] - lng)**2)
        
        if dist <= radius_deg:
            nearby_crimes.append({
                'id': row.get('id', ''),
                'type': row.get('type', 'Unknown'),
                'description': row.get('description', ''),
                'date': row.get('date', ''),
                'time': row.get('time', ''),
                'latitude': row['latitude'],
                'longitude': row['longitude'],
                'location': row.get('location', ''),
                'severity': row.get('severity', 1),
                'distance_km': dist * 111.0  # Convert back to km
            })
    
    return nearby_crimes

def get_crime_trend_data():
    """
    Get crime trend data over time for visualization
    Returns data structured for time-series charts
    """
    df = load_crime_data()
    
    if df.empty:
        return {
            'labels': [],
            'datasets': []
        }
    
    # Process data for trends
    # This assumes 'date' is in a recognizable date format
    if 'date' in df.columns:
        try:
            df['date'] = pd.to_datetime(df['date'])
            
            # Group by month and count crimes
            monthly_counts = df.groupby(df['date'].dt.strftime('%Y-%m')).size()
            
            # Prepare data for chart.js
            return {
                'labels': monthly_counts.index.tolist(),
                'datasets': [{
                    'label': 'Crime Incidents',
                    'data': monthly_counts.values.tolist(),
                    'backgroundColor': 'rgba(255, 99, 132, 0.2)',
                    'borderColor': 'rgba(255, 99, 132, 1)',
                    'borderWidth': 1
                }]
            }
        except Exception as e:
            print(f"Error processing trend data: {e}")
    
    # Return empty data structure if processing fails
    return {
        'labels': [],
        'datasets': []
    }

def get_crime_type_distribution():
    """
    Get distribution of crime types for visualization
    Returns data structured for pie/bar charts
    """
    df = load_crime_data()
    
    if df.empty or 'type' not in df.columns:
        return {
            'labels': [],
            'datasets': []
        }
    
    # Count occurrences of each crime type
    type_counts = df['type'].value_counts()
    
    # Prepare data for chart.js
    return {
        'labels': type_counts.index.tolist(),
        'datasets': [{
            'label': 'Crime Types',
            'data': type_counts.values.tolist(),
            'backgroundColor': [
                'rgba(255, 99, 132, 0.6)',
                'rgba(54, 162, 235, 0.6)',
                'rgba(255, 206, 86, 0.6)',
                'rgba(75, 192, 192, 0.6)',
                'rgba(153, 102, 255, 0.6)',
                'rgba(255, 159, 64, 0.6)',
                'rgba(199, 199, 199, 0.6)'
            ]
        }]
    }
