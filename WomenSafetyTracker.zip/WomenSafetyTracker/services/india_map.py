import os
import json
import logging
import requests
from datetime import datetime, timedelta
from urllib.parse import urlencode

# Get MapmyIndia API credentials from environment variables
MAPMYINDIA_API_KEY = "b83cd84961306211545238093c23197e"
MAPMYINDIA_CLIENT_ID = "96dHZVzsAut8H2VlHC0AqeMSLqDo2ETNcoamXKSHp9Kyk4xcGxrpMOdg8q8GrcDWUmqF15m1415c0P7DLOvqGg=="
MAPMYINDIA_CLIENT_SECRET = "lrFxI-iSEg90dIZ00qfH5FNMwekR9lyCrysmXeoc4R38JwRl3YygBdEUgyaBpnE_n0wTXhwqQe5S2nAoDstdl_lTpv_O3YGz"

# MapmyIndia API endpoints
MAPMYINDIA_ATLAS_API_URL = "https://atlas.mapmyindia.com/api"
MAPMYINDIA_OAUTH_URL = "https://outpost.mapmyindia.com/api/security/oauth/token"
MAPMYINDIA_GEOCODE_URL = "https://atlas.mapmyindia.com/api/places/geocode"
MAPMYINDIA_REV_GEOCODE_URL = "https://atlas.mapmyindia.com/api/places/reverse-geocode"
MAPMYINDIA_ROUTING_URL = "https://apis.mapmyindia.com/advancedmaps/v1"
MAPMYINDIA_DISTANCE_MATRIX_URL = "https://apis.mapmyindia.com/advancedmaps/v1"
MAPMYINDIA_NEARBY_URL = "https://atlas.mapmyindia.com/api/places/nearby/json"

# Cache for access token
_access_token = None
_token_expiry = None

def get_access_token():
    """
    Get OAuth2 access token for MapmyIndia APIs
    
    Returns:
        Access token string or None if failed
    """
    global _access_token, _token_expiry
    
    # Check if we have a valid token already
    if _access_token and _token_expiry and datetime.now() < _token_expiry:
        return _access_token
    
    try:
        if not all([MAPMYINDIA_CLIENT_ID, MAPMYINDIA_CLIENT_SECRET]):
            logging.error("MapmyIndia API credentials not set in environment variables")
            return None
            
        # Request token
        payload = {
            'grant_type': 'client_credentials',
            'client_id': MAPMYINDIA_CLIENT_ID,
            'client_secret': MAPMYINDIA_CLIENT_SECRET
        }
        
        response = requests.post(MAPMYINDIA_OAUTH_URL, data=payload)
        
        if response.status_code == 200:
            data = response.json()
            _access_token = data.get('access_token')
            # Token usually expires in 24 hours, but set expiry a bit earlier to be safe
            expiry_seconds = data.get('expires_in', 86400) - 300  # 5 minutes buffer
            _token_expiry = datetime.now() + timedelta(seconds=expiry_seconds)
            return _access_token
        else:
            logging.error(f"Failed to get MapmyIndia access token: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        logging.error(f"Error getting MapmyIndia access token: {e}")
        return None

def geocode_address(address, region="ind"):
    """
    Convert address to coordinates using MapmyIndia geocoding API
    
    Args:
        address: Address string to geocode
        region: Region code (default: ind for India)
        
    Returns:
        Dictionary with geocoding results or None if failed
    """
    try:
        if not MAPMYINDIA_API_KEY:
            logging.error("MapmyIndia API key not set in environment variables")
            return None
            
        # Prepare request
        params = {
            'address': address,
            'region': region
        }
        
        headers = {
            'Authorization': f'Bearer {get_access_token()}'
        }
        
        response = requests.get(MAPMYINDIA_GEOCODE_URL, params=params, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            if data.get('results') and len(data['results']) > 0:
                result = data['results'][0]
                
                return {
                    'latitude': result.get('latitude'),
                    'longitude': result.get('longitude'),
                    'formatted_address': result.get('formatted_address'),
                    'area': result.get('area'),
                    'city': result.get('city'),
                    'district': result.get('district'),
                    'state': result.get('state'),
                    'pincode': result.get('pincode'),
                    'poi': result.get('poi'),
                    'street': result.get('street'),
                    'sub_district': result.get('sub_district'),
                    'sub_locality': result.get('sub_locality'),
                    'house_name': result.get('house_name'),
                    'house_number': result.get('house_number'),
                    'eloc': result.get('eloc')  # eLoc is a unique 6-character code for any location in India
                }
            else:
                return None
        else:
            logging.error(f"MapmyIndia geocoding failed: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        logging.error(f"Error in MapmyIndia geocoding: {e}")
        return None

def reverse_geocode(lat, lng):
    """
    Convert coordinates to address using MapmyIndia reverse geocoding API
    
    Args:
        lat: Latitude
        lng: Longitude
        
    Returns:
        Dictionary with reverse geocoding results or None if failed
    """
    try:
        if not MAPMYINDIA_API_KEY:
            logging.error("MapmyIndia API key not set in environment variables")
            return None
            
        # Prepare request
        params = {
            'lat': lat,
            'lng': lng
        }
        
        headers = {
            'Authorization': f'Bearer {get_access_token()}'
        }
        
        response = requests.get(MAPMYINDIA_REV_GEOCODE_URL, params=params, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            if data.get('results') and len(data['results']) > 0:
                result = data['results'][0]
                
                return {
                    'formatted_address': result.get('formatted_address'),
                    'area': result.get('area'),
                    'city': result.get('city'),
                    'district': result.get('district'),
                    'state': result.get('state'),
                    'pincode': result.get('pincode'),
                    'poi': result.get('poi'),
                    'street': result.get('street'),
                    'sub_district': result.get('sub_district'),
                    'sub_locality': result.get('sub_locality'),
                    'house_name': result.get('house_name'),
                    'house_number': result.get('house_number'),
                    'eloc': result.get('eloc')
                }
            else:
                return None
        else:
            logging.error(f"MapmyIndia reverse geocoding failed: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        logging.error(f"Error in MapmyIndia reverse geocoding: {e}")
        return None

def get_safe_route(start_lat, start_lng, end_lat, end_lng):
    """
    Get a safe route between two points using MapmyIndia routing API
    
    Args:
        start_lat: Starting point latitude
        start_lng: Starting point longitude
        end_lat: Ending point latitude
        end_lng: Ending point longitude
        
    Returns:
        Dictionary with route information or None if failed
    """
    try:
        if not MAPMYINDIA_API_KEY:
            logging.error("MapmyIndia API key not set in environment variables")
            return None
            
        # Prepare request
        url = f"{MAPMYINDIA_ROUTING_URL}/{MAPMYINDIA_API_KEY}/route_adv/walking/{start_lng},{start_lat};{end_lng},{end_lat}?geometries=geojson&overview=full&alternatives=true"
        
        response = requests.get(url)
        
        if response.status_code == 200:
            data = response.json()
            if data.get('routes') and len(data['routes']) > 0:
                routes = []
                
                for i, route in enumerate(data['routes']):
                    # Convert to GeoJSON format
                    geojson = route.get('geometry', {})
                    
                    # Extract step-by-step instructions
                    steps = []
                    for leg in route.get('legs', []):
                        for step in leg.get('steps', []):
                            steps.append({
                                'instruction': step.get('name', ''),
                                'distance': step.get('distance', 0),
                                'duration': step.get('duration', 0),
                                'maneuver': step.get('maneuver', {}).get('type', '')
                            })
                    
                    routes.append({
                        'route_id': i,
                        'distance': route.get('distance', 0),
                        'duration': route.get('duration', 0),
                        'geometry': geojson,
                        'steps': steps
                    })
                
                return {
                    'routes': routes
                }
            else:
                return None
        else:
            logging.error(f"MapmyIndia routing failed: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        logging.error(f"Error in MapmyIndia routing: {e}")
        return None

def find_nearby_safety_resources(lat, lng, keyword=None, radius=5000):
    """
    Find nearby safety resources using MapmyIndia nearby API
    
    Args:
        lat: Latitude
        lng: Longitude
        keyword: Type of resource (police, hospital, etc.)
        radius: Search radius in meters (default: 5km)
        
    Returns:
        List of nearby safety resources or empty list if failed
    """
    try:
        if not get_access_token():
            logging.error("MapmyIndia API access token not available")
            return []
            
        # Set search terms based on keyword
        if keyword in ['police', 'law enforcement']:
            keywords = 'police station'
        elif keyword in ['hospital', 'medical']:
            keywords = 'hospital'
        elif keyword in ['shelter', 'women shelter']:
            keywords = 'women shelter|women hostel'
        else:
            # Default to safety-related POIs
            keywords = 'police station|hospital|women shelter|women hostel'
            
        # Prepare request
        params = {
            'lat': lat,
            'lng': lng,
            'keywords': keywords,
            'radius': radius,
            'sortBy': 'distance'
        }
        
        headers = {
            'Authorization': f'Bearer {get_access_token()}'
        }
        
        response = requests.get(MAPMYINDIA_NEARBY_URL, params=params, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            results = []
            
            if data.get('suggestions'):
                for place in data['suggestions']:
                    # Calculate distance if not provided
                    distance = place.get('distance', 0)
                    
                    results.append({
                        'name': place.get('placeName', ''),
                        'address': place.get('placeAddress', ''),
                        'type': place.get('type', ''),
                        'latitude': place.get('latitude'),
                        'longitude': place.get('longitude'),
                        'distance': distance,
                        'phone': place.get('phoneNumber'),
                        'opening_hours': place.get('openingTime'),
                        'eloc': place.get('eLoc')
                    })
            
            return results
        else:
            logging.error(f"MapmyIndia nearby search failed: {response.status_code} - {response.text}")
            return []
    except Exception as e:
        logging.error(f"Error in MapmyIndia nearby search: {e}")
        return []

def get_map_api_config():
    """
    Get MapmyIndia map configuration for frontend
    
    Returns:
        Dictionary with map configuration
    """
    return {
        'apiKey': MAPMYINDIA_API_KEY,
        'zoom': 12,  # Default zoom level
        'center': {  # Default center (Delhi)
            'lat': 28.6139,
            'lng': 77.2090
        },
        'maxBounds': {  # Restrict to India's boundaries
            'southWest': {'lat': 6.7, 'lng': 68.1},
            'northEast': {'lat': 37.6, 'lng': 97.4}
        }
    }

def get_india_states():
    """
    Get list of Indian states for form dropdowns
    
    Returns:
        List of state dictionaries
    """
    return [
        {'code': 'AN', 'name': 'Andaman and Nicobar Islands'},
        {'code': 'AP', 'name': 'Andhra Pradesh'},
        {'code': 'AR', 'name': 'Arunachal Pradesh'},
        {'code': 'AS', 'name': 'Assam'},
        {'code': 'BR', 'name': 'Bihar'},
        {'code': 'CH', 'name': 'Chandigarh'},
        {'code': 'CT', 'name': 'Chhattisgarh'},
        {'code': 'DN', 'name': 'Dadra and Nagar Haveli'},
        {'code': 'DD', 'name': 'Daman and Diu'},
        {'code': 'DL', 'name': 'Delhi'},
        {'code': 'GA', 'name': 'Goa'},
        {'code': 'GJ', 'name': 'Gujarat'},
        {'code': 'HR', 'name': 'Haryana'},
        {'code': 'HP', 'name': 'Himachal Pradesh'},
        {'code': 'JK', 'name': 'Jammu and Kashmir'},
        {'code': 'JH', 'name': 'Jharkhand'},
        {'code': 'KA', 'name': 'Karnataka'},
        {'code': 'KL', 'name': 'Kerala'},
        {'code': 'LA', 'name': 'Ladakh'},
        {'code': 'LD', 'name': 'Lakshadweep'},
        {'code': 'MP', 'name': 'Madhya Pradesh'},
        {'code': 'MH', 'name': 'Maharashtra'},
        {'code': 'MN', 'name': 'Manipur'},
        {'code': 'ML', 'name': 'Meghalaya'},
        {'code': 'MZ', 'name': 'Mizoram'},
        {'code': 'NL', 'name': 'Nagaland'},
        {'code': 'OR', 'name': 'Odisha'},
        {'code': 'PY', 'name': 'Puducherry'},
        {'code': 'PB', 'name': 'Punjab'},
        {'code': 'RJ', 'name': 'Rajasthan'},
        {'code': 'SK', 'name': 'Sikkim'},
        {'code': 'TN', 'name': 'Tamil Nadu'},
        {'code': 'TG', 'name': 'Telangana'},
        {'code': 'TR', 'name': 'Tripura'},
        {'code': 'UP', 'name': 'Uttar Pradesh'},
        {'code': 'UT', 'name': 'Uttarakhand'},
        {'code': 'WB', 'name': 'West Bengal'}
    ]

def get_india_emergency_helplines():
    """
    Get list of national emergency helplines in India
    
    Returns:
        List of emergency helpline dictionaries
    """
    return [
        {'name': 'National Emergency Number', 'number': '112', 'category': 'emergency'},
        {'name': 'Women Helpline', 'number': '1091', 'category': 'women'},
        {'name': 'Women Helpline - Domestic Abuse', 'number': '181', 'category': 'women'},
        {'name': 'Police', 'number': '100', 'category': 'police'},
        {'name': 'Fire', 'number': '101', 'category': 'fire'},
        {'name': 'Ambulance', 'number': '108', 'category': 'medical'},
        {'name': 'Disaster Management Services', 'number': '108', 'category': 'disaster'},
        {'name': 'Medical Helpline', 'number': '102', 'category': 'medical'},
        {'name': 'Child Helpline', 'number': '1098', 'category': 'child'},
        {'name': 'Railway Protection Force', 'number': '1322', 'category': 'railway'},
        {'name': 'Senior Citizen Helpline', 'number': '1091', 'category': 'senior'},
        {'name': 'Road Accident Emergency Service', 'number': '1073', 'category': 'accident'},
        {'name': 'Tourist Helpline', 'number': '1363', 'category': 'tourist'},
        {'name': 'LPG Leak Helpline', 'number': '1906', 'category': 'gas'}
    ]