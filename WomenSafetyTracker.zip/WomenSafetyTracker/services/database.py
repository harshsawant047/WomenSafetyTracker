import os
import logging
from datetime import datetime
from app import db
from models import CommunityReport, SafetyResource


def save_safety_incident(incident_data):
    """
    Save a safety incident report to SQLite database
    """
    try:
        report = CommunityReport(
            user_id=incident_data.get('user_id'),
            title=incident_data.get('title'),
            description=incident_data.get('description'),
            incident_type=incident_data.get('incident_type'),
            latitude=incident_data.get('latitude'),
            longitude=incident_data.get('longitude'),
            location_name=incident_data.get('location_name'),
            state=incident_data.get('state'),
            district=incident_data.get('district'),
            city=incident_data.get('city'),
            pincode=incident_data.get('pincode'),
            severity=incident_data.get('severity', 3),
            created_at=datetime.utcnow()
        )
        db.session.add(report)
        db.session.commit()
        return report.id
    except Exception as e:
        logging.error(f"Error saving incident to database: {e}")
        db.session.rollback()
        return None

def get_safety_incidents(query=None, limit=100):
    """
    Get safety incidents from SQLite database
    """
    try:
        incidents = CommunityReport.query
        if query:
            if 'state' in query:
                incidents = incidents.filter_by(state=query['state'])
            if 'district' in query:
                incidents = incidents.filter_by(district=query['district'])
            if 'city' in query:
                incidents = incidents.filter_by(city=query['city'])

        return incidents.order_by(CommunityReport.created_at.desc()).limit(limit).all()
    except Exception as e:
        logging.error(f"Error getting incidents from database: {e}")
        return []

def get_safety_incidents_by_location(lat, lng, radius_km, limit=100):
    """
    Get safety incidents near a specific location
    Basic implementation using square bounding box
    """
    try:
        # Convert radius to rough lat/lng degrees (approximate)
        lat_radius = radius_km / 111.0  # 1 degree = ~111km
        lng_radius = radius_km / (111.0 * abs(lat))

        incidents = CommunityReport.query.filter(
            CommunityReport.latitude.between(lat - lat_radius, lat + lat_radius),
            CommunityReport.longitude.between(lng - lng_radius, lng + lng_radius)
        ).limit(limit).all()

        return incidents
    except Exception as e:
        logging.error(f"Error getting incidents by location: {e}")
        return []

#Removed functions that are not compatible with SQLite
# def get_collection(collection_name): ...
# def aggregate_safety_stats_by_area(area_query, group_by='district'): ...
# ... other MongoDB-specific functions ...