from datetime import datetime
from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    first_name = db.Column(db.String(50))
    last_name = db.Column(db.String(50))
    phone_number = db.Column(db.String(20))
    # India-specific location info
    state = db.Column(db.String(50))
    city = db.Column(db.String(50))
    district = db.Column(db.String(50))
    pincode = db.Column(db.String(10))
    address = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    emergency_contacts = db.relationship('EmergencyContact', backref='user', lazy=True)
    reports = db.relationship('CommunityReport', backref='author', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'

class EmergencyContact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    phone_number = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(120))
    relationship = db.Column(db.String(50))
    
    def __repr__(self):
        return f'<EmergencyContact {self.name}>'

class CommunityReport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    incident_type = db.Column(db.String(50), nullable=False)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    location_name = db.Column(db.String(200))
    # India-specific location data
    state = db.Column(db.String(50))
    district = db.Column(db.String(50))
    city = db.Column(db.String(50))
    pincode = db.Column(db.String(10))
    landmark = db.Column(db.String(100))
    police_jurisdiction = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_anonymous = db.Column(db.Boolean, default=False)
    # Severity rating (1-5, where 5 is most severe)
    severity = db.Column(db.Integer, default=3)
    # Status of the report
    status = db.Column(db.String(20), default='reported')  # reported, verified, resolved
    
    def __repr__(self):
        return f'<CommunityReport {self.title}>'

class SafetyResource(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    resource_type = db.Column(db.String(50), nullable=False)  # police, hospital, shelter, ngo, helpline etc.
    description = db.Column(db.Text)
    address = db.Column(db.String(200))
    phone_number = db.Column(db.String(20))
    alternate_phone = db.Column(db.String(20))
    email = db.Column(db.String(100))
    website = db.Column(db.String(200))
    
    # India-specific location data
    state = db.Column(db.String(50))
    district = db.Column(db.String(50))
    city = db.Column(db.String(50))
    pincode = db.Column(db.String(10))
    landmark = db.Column(db.String(100))
    
    # Geographical coordinates
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    
    # Additional Info
    hours_of_operation = db.Column(db.String(200))
    services_offered = db.Column(db.Text)
    languages_supported = db.Column(db.String(200))
    is_verified = db.Column(db.Boolean, default=False)
    
    def __repr__(self):
        return f'<SafetyResource {self.name}>'
        
# New table for India-specific administrative boundaries
class IndiaAdminBoundary(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    boundary_type = db.Column(db.String(50), nullable=False)  # state, district, city, locality
    parent_id = db.Column(db.Integer, db.ForeignKey('india_admin_boundary.id'), nullable=True)
    
    # Geographic info
    polygon_data = db.Column(db.Text)  # GeoJSON data for boundary
    center_latitude = db.Column(db.Float)
    center_longitude = db.Column(db.Float)
    
    # Stats for this boundary
    population = db.Column(db.Integer)
    area_sqkm = db.Column(db.Float)
    safety_score = db.Column(db.Float)  # 0-100, higher is safer
    
    # Relationships
    children = db.relationship(
        'IndiaAdminBoundary', 
        backref=db.backref('parent', remote_side=[id]),
        lazy='dynamic'
    )
    
    def __repr__(self):
        return f'<IndiaAdminBoundary {self.boundary_type}: {self.name}>'

# Emergency helplines specific to India
class IndiaEmergencyHelpline(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False) 
    helpline_number = db.Column(db.String(20), nullable=False)
    alternate_number = db.Column(db.String(20))
    category = db.Column(db.String(50), nullable=False)  # police, ambulance, women, child, etc.
    description = db.Column(db.Text)
    
    # Geographical scope
    scope = db.Column(db.String(50))  # national, state, district, city
    state = db.Column(db.String(50))
    district = db.Column(db.String(50))
    city = db.Column(db.String(50))
    
    # Additional info
    operates_24x7 = db.Column(db.Boolean, default=True)
    languages = db.Column(db.String(200))
    website = db.Column(db.String(200))
    
    def __repr__(self):
        return f'<IndiaEmergencyHelpline {self.name}: {self.helpline_number}>'
