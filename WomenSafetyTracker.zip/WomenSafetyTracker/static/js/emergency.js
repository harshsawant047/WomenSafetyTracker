// Emergency.js - Handles emergency functionality for the Women's Safety App

// Variables to track emergency state
let emergencyActive = false;
let locationWatchId = null;
let lastLocation = null;
let emergencyContacts = [];

// Initialize emergency functionality
function initEmergencyFeatures() {
    // Set up SOS button
    setupSosButton();
    
    // Set up emergency contact selection
    setupEmergencyContactSelection();
    
    // Listen for location updates
    document.addEventListener('user-location-updated', function(event) {
        lastLocation = {
            lat: event.detail.lat,
            lng: event.detail.lng
        };
    });
    
    console.log('Emergency features initialized');
}

// Set up SOS button functionality
function setupSosButton() {
    const sosButton = document.getElementById('sos-button');
    
    if (sosButton) {
        sosButton.addEventListener('click', function() {
            if (emergencyActive) {
                cancelEmergency();
            } else {
                triggerEmergency();
            }
        });
    }
}

// Enable shake detection for SOS
function setupShakeDetection() {
    const shakeToggle = document.getElementById('shake-detection-toggle');
    const sensitivitySlider = document.getElementById('shake-sensitivity');
    
    // Set up sensitivity slider if it exists
    if (sensitivitySlider) {
        sensitivitySlider.addEventListener('input', function() {
            shakeSensitivity = parseInt(this.value);
            // Save preference
            localStorage.setItem('shakeSensitivity', shakeSensitivity);
        });
        
        // Load saved sensitivity
        const savedSensitivity = localStorage.getItem('shakeSensitivity');
        if (savedSensitivity) {
            shakeSensitivity = parseInt(savedSensitivity);
            sensitivitySlider.value = shakeSensitivity;
        }
    }
    
    // Set up shake detection toggle
    if (shakeToggle) {
        // Load saved preference
        const shakeEnabled = localStorage.getItem('shakeDetectionEnabled') === 'true';
        shakeToggle.checked = shakeEnabled;
        shakeDetectionEnabled = shakeEnabled;
        
        shakeToggle.addEventListener('change', function() {
            shakeDetectionEnabled = this.checked;
            
            // Save preference
            localStorage.setItem('shakeDetectionEnabled', shakeDetectionEnabled);
            
            if (shakeDetectionEnabled) {
                enableShakeDetection();
            } else {
                disableShakeDetection();
            }
        });
        
        // Initialize based on saved preference
        if (shakeDetectionEnabled) {
            enableShakeDetection();
        }
    }
}

// Enable shake detection
function enableShakeDetection() {
    // Check if DeviceMotionEvent is available
    if (typeof DeviceMotionEvent !== 'undefined' && typeof DeviceMotionEvent.requestPermission === 'function') {
        // iOS 13+ requires permission
        DeviceMotionEvent.requestPermission()
            .then(response => {
                if (response === 'granted') {
                    window.addEventListener('devicemotion', handleShake);
                    console.log('Shake detection enabled (iOS)');
                } else {
                    console.log('Device motion permission denied');
                    showPermissionDeniedMessage('shake detection');
                }
            })
            .catch(error => {
                console.error('Error requesting device motion permission:', error);
            });
    } else {
        // Other devices
        window.addEventListener('devicemotion', handleShake);
        console.log('Shake detection enabled');
    }
}

// Disable shake detection
function disableShakeDetection() {
    window.removeEventListener('devicemotion', handleShake);
    console.log('Shake detection disabled');
}

// Handle device shake event
let lastShakeTime = 0;
let lastAccel = { x: 0, y: 0, z: 0 };
let shakeCount = 0;

function handleShake(event) {
    if (!shakeDetectionEnabled || emergencyActive) return;
    
    const now = new Date().getTime();
    
    // Throttle processing to every 100ms
    if (now - lastShakeTime < 100) return;
    
    lastShakeTime = now;
    
    const acceleration = event.accelerationIncludingGravity;
    
    if (!acceleration) return;
    
    const deltaX = Math.abs(acceleration.x - lastAccel.x);
    const deltaY = Math.abs(acceleration.y - lastAccel.y);
    const deltaZ = Math.abs(acceleration.z - lastAccel.z);
    
    lastAccel = {
        x: acceleration.x,
        y: acceleration.y,
        z: acceleration.z
    };
    
    // Calculate movement intensity
    const totalAccel = Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
    
    // Adjust threshold based on sensitivity (higher value = lower sensitivity)
    const threshold = 30 - shakeSensitivity;
    
    if (totalAccel > threshold) {
        shakeCount++;
        
        // Require multiple shakes to trigger emergency
        if (shakeCount >= 3) {
            triggerEmergency();
            shakeCount = 0;
        }
        
        // Reset shake count after 2 seconds of no significant movement
        setTimeout(() => {
            shakeCount = 0;
        }, 2000);
    }
}

// Show permission denied message
function showPermissionDeniedMessage(featureName) {
    const toast = document.createElement('div');
    toast.className = 'toast align-items-center text-white bg-warning border-0 position-fixed top-0 end-0 m-3';
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                <strong>Permission Denied:</strong> To use ${featureName}, please grant the required permissions in your device settings.
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    document.body.appendChild(toast);
    
    // Show the toast
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
}

// Set up emergency contact selection
function setupEmergencyContactSelection() {
    const contactSelector = document.getElementById('emergency-contacts-selector');
    
    if (contactSelector) {
        // Update contacts when checkboxes change
        contactSelector.addEventListener('change', function(event) {
            if (event.target.type === 'checkbox') {
                const contactId = event.target.value;
                const isSelected = event.target.checked;
                
                updateSelectedContacts(contactId, isSelected);
            }
        });
        
        // Load saved contacts
        loadSelectedContacts();
    }
}

// Update selected contacts
function updateSelectedContacts(contactId, isSelected) {
    // Load current selection
    let selectedContacts = JSON.parse(localStorage.getItem('selectedEmergencyContacts') || '[]');
    
    if (isSelected) {
        // Add contact if not already in list
        if (!selectedContacts.includes(contactId)) {
            selectedContacts.push(contactId);
        }
    } else {
        // Remove contact
        selectedContacts = selectedContacts.filter(id => id !== contactId);
    }
    
    // Save updated selection
    localStorage.setItem('selectedEmergencyContacts', JSON.stringify(selectedContacts));
    emergencyContacts = selectedContacts;
}

// Load selected contacts
function loadSelectedContacts() {
    const selectedContacts = JSON.parse(localStorage.getItem('selectedEmergencyContacts') || '[]');
    emergencyContacts = selectedContacts;
    
    // Check the appropriate checkboxes
    selectedContacts.forEach(contactId => {
        const checkbox = document.querySelector(`input[type="checkbox"][value="${contactId}"]`);
        if (checkbox) {
            checkbox.checked = true;
        }
    });
}

// Trigger emergency response
function triggerEmergency() {
    if (emergencyActive) return;
    
    emergencyActive = true;
    
    // Update UI
    updateEmergencyUI(true);
    
    // Start tracking location more frequently
    locationWatchId = window.safetyMap.startLocationTracking();
    
    // Send initial SOS alert
    sendSOSAlert();
    
    // Set up countdown timer for auto-escalation (optional feature)
    setupEscalationTimer();
    
    console.log('Emergency triggered');
}

// Cancel emergency response
function cancelEmergency() {
    if (!emergencyActive) return;
    
    emergencyActive = false;
    
    // Update UI
    updateEmergencyUI(false);
    
    // Stop continuous location tracking
    if (locationWatchId !== null) {
        window.safetyMap.stopLocationTracking(locationWatchId);
        locationWatchId = null;
    }
    
    // Clear any timers
    clearEscalationTimer();
    
    console.log('Emergency cancelled');
}

// Update UI elements during emergency
function updateEmergencyUI(isActive) {
    const sosButton = document.getElementById('sos-button');
    const sosStatus = document.getElementById('sos-status');
    const emergencyInstructions = document.getElementById('emergency-instructions');
    
    if (sosButton) {
        if (isActive) {
            sosButton.textContent = 'CANCEL SOS';
            sosButton.classList.remove('btn-danger');
            sosButton.classList.add('btn-warning');
        } else {
            sosButton.textContent = 'SOS EMERGENCY';
            sosButton.classList.remove('btn-warning');
            sosButton.classList.add('btn-danger');
        }
    }
    
    if (sosStatus) {
        sosStatus.textContent = isActive ? 'EMERGENCY ACTIVE' : 'No active emergency';
        sosStatus.className = isActive ? 'alert alert-danger' : 'd-none';
    }
    
    if (emergencyInstructions) {
        emergencyInstructions.className = isActive ? 'mt-3' : 'd-none';
    }
}

// Send SOS alert to server
function sendSOSAlert() {
    // Check if we have location data
    if (!lastLocation) {
        console.error('No location data available for SOS alert');
        showNoLocationError();
        return;
    }
    
    // Prepare SOS data
    const sosData = {
        lat: lastLocation.lat,
        lng: lastLocation.lng,
        timestamp: new Date().toISOString(),
        user_id: getUserId(), // Get from the page or session
        emergency_contacts: emergencyContacts
    };
    
    // Check if online
    if (navigator.onLine) {
        // Send to server
        fetch('/api/send-sos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': getCSRFToken() // Get CSRF token if needed
            },
            body: JSON.stringify(sosData)
        })
        .then(response => response.json())
        .then(data => {
            console.log('SOS alert sent:', data);
            showAlertSentConfirmation(data);
        })
        .catch(error => {
            console.error('Error sending SOS alert:', error);
            // Fallback to offline handling
            queueOfflineSOSAlert(sosData);
        });
    } else {
        // Queue for later if offline
        queueOfflineSOSAlert(sosData);
    }
}

// Queue SOS alert when offline
function queueOfflineSOSAlert(sosData) {
    console.log('Device offline, queuing SOS alert for later');
    
    // Get existing queue
    let queuedAlerts = JSON.parse(localStorage.getItem('offlineSOSQueue') || '[]');
    
    // Add current alert
    queuedAlerts.push(sosData);
    
    // Save updated queue
    localStorage.setItem('offlineSOSQueue', JSON.stringify(queuedAlerts));
    
    // Show offline notification
    showOfflineSosNotification();
}

// Process offline SOS queue when back online
function processOfflineSOSQueue() {
    // Get queued alerts
    const queuedAlerts = JSON.parse(localStorage.getItem('offlineSOSQueue') || '[]');
    
    if (queuedAlerts.length === 0) return;
    
    console.log(`Processing ${queuedAlerts.length} offline SOS alerts`);
    
    // Process each alert
    const processingPromises = queuedAlerts.map(sosData => 
        fetch('/api/send-sos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': getCSRFToken()
            },
            body: JSON.stringify(sosData)
        })
        .then(response => response.json())
        .catch(error => {
            console.error('Error sending queued SOS alert:', error);
            return { error: true, message: error.message };
        })
    );
    
    // When all are processed, clear the queue
    Promise.all(processingPromises)
        .then(results => {
            console.log('All queued SOS alerts processed', results);
            localStorage.removeItem('offlineSOSQueue');
        });
}

// Listen for online status changes
window.addEventListener('online', function() {
    console.log('Device back online, processing queued SOS alerts');
    processOfflineSOSQueue();
});

// Show notification when SOS is queued offline
function showOfflineSosNotification() {
    const notification = document.createElement('div');
    notification.className = 'alert alert-warning';
    notification.innerHTML = `
        <strong>You are offline!</strong> Your emergency alert has been saved and will be sent when your device reconnects.
        <hr>
        <p>Please try to find an area with better connectivity or Wi-Fi.</p>
    `;
    
    // Find or create container
    let container = document.getElementById('sos-notifications');
    if (!container) {
        container = document.createElement('div');
        container.id = 'sos-notifications';
        container.className = 'mt-3';
        
        // Find a place to insert it
        const sosButton = document.getElementById('sos-button');
        if (sosButton) {
            sosButton.parentNode.insertBefore(container, sosButton.nextSibling);
        } else {
            document.body.appendChild(container);
        }
    }
    
    container.appendChild(notification);
}

// Show error when location is not available
function showNoLocationError() {
    const notification = document.createElement('div');
    notification.className = 'alert alert-danger';
    notification.innerHTML = `
        <strong>Location unavailable!</strong> We can't send your precise location with the SOS alert.
        <hr>
        <p>Please check your device location settings and ensure location services are enabled.</p>
    `;
    
    // Find or create container
    let container = document.getElementById('sos-notifications');
    if (!container) {
        container = document.createElement('div');
        container.id = 'sos-notifications';
        container.className = 'mt-3';
        
        // Find a place to insert it
        const sosButton = document.getElementById('sos-button');
        if (sosButton) {
            sosButton.parentNode.insertBefore(container, sosButton.nextSibling);
        } else {
            document.body.appendChild(container);
        }
    }
    
    container.appendChild(notification);
}

// Show confirmation when alert is sent
function showAlertSentConfirmation(data) {
    const notification = document.createElement('div');
    notification.className = 'alert alert-success';
    
    // Create content based on response
    let content = `<strong>SOS Alert Sent!</strong>`;
    
    if (data.notified_contacts && data.notified_contacts.length > 0) {
        content += ` Your alert was sent to ${data.notified_contacts.length} emergency contacts.`;
    }
    
    notification.innerHTML = content;
    
    // Find or create container
    let container = document.getElementById('sos-notifications');
    if (!container) {
        container = document.createElement('div');
        container.id = 'sos-notifications';
        container.className = 'mt-3';
        
        // Find a place to insert it
        const sosButton = document.getElementById('sos-button');
        if (sosButton) {
            sosButton.parentNode.insertBefore(container, sosButton.nextSibling);
        } else {
            document.body.appendChild(container);
        }
    }
    
    // Clear previous notifications
    container.innerHTML = '';
    container.appendChild(notification);
}

// Set up escalation timer (auto-call emergency services after countdown)
let escalationTimer = null;
let escalationCount = 30; // 30 seconds countdown

function setupEscalationTimer() {
    // Clear any existing timer
    clearEscalationTimer();
    
    // Get UI element
    const timerElement = document.getElementById('escalation-timer');
    if (!timerElement) return;
    
    // Reset count
    escalationCount = 30;
    timerElement.textContent = escalationCount;
    timerElement.parentElement.classList.remove('d-none');
    
    // Start countdown
    escalationTimer = setInterval(() => {
        escalationCount--;
        timerElement.textContent = escalationCount;
        
        if (escalationCount <= 0) {
            // Time's up - escalate
            clearEscalationTimer();
            escalateEmergency();
        }
    }, 1000);
}

// Clear escalation timer
function clearEscalationTimer() {
    if (escalationTimer !== null) {
        clearInterval(escalationTimer);
        escalationTimer = null;
        
        // Hide timer UI
        const timerContainer = document.getElementById('escalation-timer');
        if (timerContainer) {
            timerContainer.parentElement.classList.add('d-none');
        }
    }
}

// Escalate emergency (would integrate with emergency services in production)
function escalateEmergency() {
    console.log('Emergency escalated - would contact emergency services in production');
    
    // Show escalation notification
    const notification = document.createElement('div');
    notification.className = 'alert alert-danger';
    notification.innerHTML = `
        <strong>Emergency Escalated!</strong>
        <hr>
        <p>In a production system, this would automatically contact emergency services.</p>
    `;
    
    // Find or create container
    let container = document.getElementById('sos-notifications');
    if (!container) {
        container = document.createElement('div');
        container.id = 'sos-notifications';
        container.className = 'mt-3';
        document.body.appendChild(container);
    }
    
    container.appendChild(notification);
}

// Helper function to get CSRF token
function getCSRFToken() {
    // Get token from meta tag
    const tokenElement = document.querySelector('meta[name="csrf-token"]');
    if (tokenElement) {
        return tokenElement.getAttribute('content');
    }
    return '';
}

// Helper function to get user ID
function getUserId() {
    // Get user ID from data attribute or other source
    const userIdElement = document.getElementById('user-data');
    if (userIdElement) {
        return userIdElement.dataset.userId;
    }
    return '';
}

// Export functions for use in other scripts
window.safetyEmergency = {
    initEmergencyFeatures,
    triggerEmergency,
    cancelEmergency
};
