// Charts.js - Handles data visualization using Chart.js for the Women's Safety App

// Initialize and draw a crime heatmap chart
function initCrimeHeatmapChart(chartId, data) {
    const ctx = document.getElementById(chartId).getContext('2d');
    
    return new Chart(ctx, {
        type: 'heatmap',
        data: {
            datasets: [{
                label: 'Crime Heatmap',
                data: data,
                borderWidth: 1,
                borderColor: '#ffffff',
                backgroundColor: function(context) {
                    const value = context.dataset.data[context.dataIndex].v;
                    const alpha = (value / 10); // Normalize
                    return `rgba(255, 0, 0, ${alpha})`;
                }
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = context.dataset.data[context.dataIndex].v;
                            return `Crime intensity: ${value}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    type: 'linear',
                    position: 'bottom',
                    min: 0,
                    max: 9,
                    title: {
                        display: true,
                        text: 'Area'
                    }
                },
                y: {
                    type: 'linear',
                    min: 0,
                    max: 9,
                    title: {
                        display: true,
                        text: 'Time of Day'
                    }
                }
            }
        }
    });
}

// Draw a crime trend chart (time series)
function createCrimeTrendChart(chartId, data) {
    const ctx = document.getElementById(chartId).getContext('2d');
    
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: data.datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Crime Trends Over Time'
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                }
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Month'
                    }
                },
                y: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Number of Incidents'
                    },
                    suggestedMin: 0
                }
            }
        }
    });
}

// Create a crime types distribution chart (pie/bar)
function createCrimeTypeChart(chartId, data, chartType = 'pie') {
    const ctx = document.getElementById(chartId).getContext('2d');
    
    return new Chart(ctx, {
        type: chartType,
        data: {
            labels: data.labels,
            datasets: data.datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Crime Type Distribution'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

// Create a risk score gauge chart
function createRiskScoreGauge(chartId, score) {
    const ctx = document.getElementById(chartId).getContext('2d');
    
    return new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Risk', 'Safe'],
            datasets: [{
                data: [score, 100 - score],
                backgroundColor: [
                    getColorForRiskScore(score),
                    '#e0e0e0'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            circumference: 180,
            rotation: 270,
            cutout: '75%',
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    enabled: false
                }
            }
        },
        plugins: [{
            id: 'risk-score-label',
            afterDraw: function(chart) {
                const width = chart.width;
                const height = chart.height;
                const ctx = chart.ctx;
                
                ctx.restore();
                
                // Risk score text
                const fontSize = Math.min(height / 5, width / 5);
                ctx.font = `${fontSize}px sans-serif`;
                ctx.textBaseline = 'middle';
                ctx.textAlign = 'center';
                
                // Risk score value
                ctx.fillStyle = getTextColorForRiskScore(score);
                ctx.fillText(score, width / 2, height / 2);
                
                // Risk level text
                ctx.font = `${fontSize / 2}px sans-serif`;
                let riskLevel;
                if (score < 25) riskLevel = 'Low Risk';
                else if (score < 50) riskLevel = 'Medium Risk';
                else if (score < 75) riskLevel = 'High Risk';
                else riskLevel = 'Very High Risk';
                
                ctx.fillText(riskLevel, width / 2, height / 2 + fontSize * 0.8);
                ctx.save();
            }
        }]
    });
}

// Helper function to get color based on risk score
function getColorForRiskScore(score) {
    if (score < 25) return '#28a745'; // Green - Low risk
    if (score < 50) return '#ffc107'; // Yellow - Medium risk
    if (score < 75) return '#fd7e14'; // Orange - High risk
    return '#dc3545'; // Red - Very high risk
}

// Helper function to get text color based on risk score
function getTextColorForRiskScore(score) {
    if (score < 50) return '#212529'; // Dark text for light backgrounds
    return '#ffffff'; // White text for dark backgrounds
}

// Create a comparative safety chart (radar chart) for different cities
function createCityComparisonChart(chartId, cities) {
    const ctx = document.getElementById(chartId).getContext('2d');
    
    // Extract the data
    const labels = ['Overall Safety', 'Street Safety', 'Public Transport', 'Night Safety', 'Women-specific Safety'];
    const datasets = [];
    
    for (let city of cities) {
        datasets.push({
            label: city.name,
            data: [
                city.scores.overall,
                city.scores.street,
                city.scores.transport,
                city.scores.night,
                city.scores.women
            ],
            fill: true,
            backgroundColor: `rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, 0.2)`,
            borderColor: `rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, 1)`,
            pointBackgroundColor: `rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, 1)`,
            pointBorderColor: '#fff',
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: `rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, 1)`
        });
    }
    
    return new Chart(ctx, {
        type: 'radar',
        data: {
            labels: labels,
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            elements: {
                line: {
                    borderWidth: 3
                }
            },
            scales: {
                r: {
                    angleLines: {
                        display: true
                    },
                    suggestedMin: 0,
                    suggestedMax: 100
                }
            }
        }
    });
}

// Export functions for use in other scripts
window.safetyCharts = {
    initCrimeHeatmapChart,
    createCrimeTrendChart,
    createCrimeTypeChart,
    createRiskScoreGauge,
    createCityComparisonChart,
    getColorForRiskScore
};
