// Map.js - Handles map and geolocation functions for the Women's Safety App

let map, userMarker, heatmapLayer, safetyResourcesLayer;
let userLocation = null;

// Initialize the map
function initMap(elementId, center = [20.5937, 78.9629], zoom = 5) {
    // Create the map with India as default center
    map = L.map(elementId).setView(center, zoom);
    
    // Add the base tile layer (OpenStreetMap)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
        // Set bounds to India's general area
        bounds: [
            [6.7, 68.1],  // Southwest corner: Kanyakumari region
            [37.6, 97.4]  // Northeast corner: Jammu, Kashmir, and Ladakh region
        ]
    }).addTo(map);
    
    // Add a scale control
    L.control.scale().addTo(map);
    
    // Get user's current location
    getUserLocation();
    
    return map;
}

// Get the user's current location
function getUserLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            // Success callback
            (position) => {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                
                // Store user location
                userLocation = { lat, lng };
                
                // Update the map view
                map.setView([lat, lng], 15);
                
                // Create or update user marker
                if (userMarker) {
                    userMarker.setLatLng([lat, lng]);
                } else {
                    // Create user marker with custom icon
                    const userIcon = L.divIcon({
                        html: '<i class="fas fa-user-circle fa-2x" style="color: #007bff;"></i>',
                        className: 'user-marker',
                        iconSize: [24, 24],
                        iconAnchor: [12, 12]
                    });
                    
                    userMarker = L.marker([lat, lng], { icon: userIcon }).addTo(map);
                    userMarker.bindPopup('Your current location').openPopup();
                }
                
                // Emit custom event for location update
                document.dispatchEvent(new CustomEvent('user-location-updated', { 
                    detail: { lat, lng } 
                }));
            },
            // Error callback
            (error) => {
                console.error('Error getting location:', error);
                displayLocationError(error);
            },
            // Options
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            }
        );
    } else {
        displayLocationError({ code: 0, message: 'Geolocation is not supported by this browser.' });
    }
}

// Start tracking user location
function startLocationTracking() {
    if (navigator.geolocation) {
        // Watch position with high accuracy
        const watchId = navigator.geolocation.watchPosition(
            // Success callback
            (position) => {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                
                // Store user location
                userLocation = { lat, lng };
                
                // Update the map view
                if (map) {
                    // Update user marker
                    if (userMarker) {
                        userMarker.setLatLng([lat, lng]);
                    } else {
                        const userIcon = L.divIcon({
                            html: '<i class="fas fa-user-circle fa-2x" style="color: #007bff;"></i>',
                            className: 'user-marker',
                            iconSize: [24, 24],
                            iconAnchor: [12, 12]
                        });
                        
                        userMarker = L.marker([lat, lng], { icon: userIcon }).addTo(map);
                    }
                }
                
                // Emit custom event for location update
                document.dispatchEvent(new CustomEvent('user-location-updated', { 
                    detail: { lat, lng } 
                }));
            },
            // Error callback
            (error) => {
                console.error('Error tracking location:', error);
                displayLocationError(error);
            },
            // Options
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 5000
            }
        );
        
        return watchId;
    } else {
        displayLocationError({ code: 0, message: 'Geolocation is not supported by this browser.' });
        return null;
    }
}

// Stop tracking user location
function stopLocationTracking(watchId) {
    if (watchId && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchId);
    }
}

// Display location error message
function displayLocationError(error) {
    let errorMessage;
    
    switch(error.code) {
        case error.PERMISSION_DENIED:
            errorMessage = "Location access was denied. Please enable location services to use all features.";
            break;
        case error.POSITION_UNAVAILABLE:
            errorMessage = "Location information is unavailable. Please try again later.";
            break;
        case error.TIMEOUT:
            errorMessage = "The request to get your location timed out. Please try again.";
            break;
        default:
            errorMessage = "An unknown error occurred while trying to get your location.";
            break;
    }
    
    // Display error (could be shown in a modal or alert)
    console.error(errorMessage);
    
    // Show error message on page
    const errorContainer = document.getElementById('location-error');
    if (errorContainer) {
        errorContainer.textContent = errorMessage;
        errorContainer.style.display = 'block';
    } else {
        // Create a toast notification
        const toast = document.createElement('div');
        toast.className = 'toast align-items-center text-white bg-danger border-0 position-fixed bottom-0 end-0 m-3';
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${errorMessage}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;
        document.body.appendChild(toast);
        
        // Show the toast
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
    }
}

// Create and display a heatmap from crime data
function createCrimeHeatmap(data) {
    // Remove existing heatmap if any
    if (heatmapLayer) {
        map.removeLayer(heatmapLayer);
    }
    
    // Format data for Leaflet.heat
    const heatmapData = data.map(point => [
        point[0],  // latitude
        point[1],  // longitude
        point[2]   // intensity
    ]);
    
    // Create the heatmap layer with enhanced settings for better visibility
    heatmapLayer = L.heatLayer(heatmapData, {
        radius: 50,  // Increased from 25 to 50
        blur: 30,    // Increased from 15 to 30
        maxZoom: 15, // Decreased from 17 to 15 for better area coverage
        minOpacity: 0.5, // Add minimum opacity so heatmap is always visible
        max: 1.0,    // Maximum value for intensity normalization
        gradient: {
            0.3: 'blue',
            0.5: 'cyan',
            0.7: 'lime',
            0.8: 'yellow',
            1.0: 'red'
        }
    }).addTo(map);
    
    return heatmapLayer;
}

// Display safety resources on the map
function displaySafetyResources(resources) {
    // Remove existing layer if any
    if (safetyResourcesLayer) {
        map.removeLayer(safetyResourcesLayer);
    }
    
    // Create new layer group
    safetyResourcesLayer = L.layerGroup().addTo(map);
    
    // Define icons for different resource types
    const icons = {
        police: L.divIcon({
            html: '<i class="fas fa-shield-alt fa-lg" style="color: #0066cc;"></i>',
            className: 'resource-marker',
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        }),
        hospital: L.divIcon({
            html: '<i class="fas fa-hospital fa-lg" style="color: #cc0000;"></i>',
            className: 'resource-marker',
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        }),
        shelter: L.divIcon({
            html: '<i class="fas fa-home fa-lg" style="color: #009900;"></i>',
            className: 'resource-marker',
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        }),
        default: L.divIcon({
            html: '<i class="fas fa-building fa-lg" style="color: #666666;"></i>',
            className: 'resource-marker',
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        })
    };
    
    // Add markers for each resource
    resources.forEach(resource => {
        const icon = icons[resource.type] || icons.default;
        
        const marker = L.marker([resource.lat, resource.lng], {
            icon: icon
        }).addTo(safetyResourcesLayer);
        
        // Create popup content
        const popupContent = `
            <strong>${resource.name}</strong><br>
            <em>${resource.type}</em><br>
            ${resource.address ? resource.address + '<br>' : ''}
            ${resource.phone ? 'Phone: ' + resource.phone : ''}
        `;
        
        marker.bindPopup(popupContent);
    });
    
    return safetyResourcesLayer;
}

// Display a route on the map
function displayRoute(routeGeometry, options = {}) {
    // Default options
    const defaultOptions = {
        color: "#3388ff",
        weight: 5,
        opacity: 0.7,
        lineJoin: 'round'
    };
    
    // Merge options
    const routeOptions = { ...defaultOptions, ...options };
    
    // Create GeoJSON object
    const route = L.geoJSON(routeGeometry, {
        style: routeOptions
    }).addTo(map);
    
    // Fit map to route bounds
    map.fitBounds(route.getBounds());
    
    return route;
}

// Display multiple routes on the map
function displayMultipleRoutes(routes) {
    // Colors for different routes
    const routeColors = ['#3388ff', '#ff3333', '#33cc33', '#9933cc'];
    
    // Layer group for all routes
    const routesLayer = L.layerGroup().addTo(map);
    
    // Display each route with a different color
    routes.forEach((route, index) => {
        const color = routeColors[index % routeColors.length];
        
        // Create GeoJSON layer
        const routeLayer = L.geoJSON(route.geometry, {
            style: {
                color: color,
                weight: 5,
                opacity: 0.7,
                lineJoin: 'round'
            }
        }).addTo(routesLayer);
        
        // Add risk level indicator
        if (route.safety && route.safety.risk_level) {
            // Add risk markers along the route
            route.safety.risk_points.forEach(point => {
                // Determine marker color based on risk level
                let markerColor;
                switch(point.risk_level) {
                    case 'low':
                        markerColor = '#33cc33';
                        break;
                    case 'medium':
                        markerColor = '#ffcc00';
                        break;
                    case 'high':
                        markerColor = '#ff9900';
                        break;
                    case 'very high':
                        markerColor = '#ff3333';
                        break;
                    default:
                        markerColor = '#999999';
                }
                
                // Create small circle marker
                L.circleMarker([point.latitude, point.longitude], {
                    radius: 5,
                    fillColor: markerColor,
                    color: '#ffffff',
                    weight: 1,
                    opacity: 1,
                    fillOpacity: 0.7
                }).addTo(routesLayer);
            });
        }
    });
    
    // Fit map to all routes
    if (routes.length > 0 && routes[0].geometry) {
        const bounds = L.geoJSON(routes[0].geometry).getBounds();
        for (let i = 1; i < routes.length; i++) {
            if (routes[i].geometry) {
                bounds.extend(L.geoJSON(routes[i].geometry).getBounds());
            }
        }
        map.fitBounds(bounds);
    }
    
    return routesLayer;
}

// Export functions for use in other scripts
window.safetyMap = {
    initMap,
    getUserLocation,
    startLocationTracking,
    stopLocationTracking,
    createCrimeHeatmap,
    displaySafetyResources,
    displayRoute,
    displayMultipleRoutes
};
